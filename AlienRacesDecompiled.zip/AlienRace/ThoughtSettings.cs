using RimWorld;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace AlienRace
{
	public class ThoughtSettings
	{
		public List<string> cannotReceiveThoughts;

		public bool cannotReceiveThoughtsAtAll;

		public List<string> canStillReceiveThoughts;

		public static Dictionary<ThoughtDef, List<ThingDef_AlienRace>> thoughtRestrictionDict = new Dictionary<ThoughtDef, List<ThingDef_AlienRace>>();

		public List<string> restrictedThoughts = new List<string>();

		public ButcherThought butcherThoughtGeneral = new ButcherThought();

		public List<ButcherThought> butcherThoughtSpecific = new List<ButcherThought>();

		public AteThought ateThoughtGeneral = new AteThought();

		public List<AteThought> ateThoughtSpecific = new List<AteThought>();

		public List<ThoughtReplacer> replacerList;

		public ThoughtDef ReplaceIfApplicable(ThoughtDef def)
		{
			ThoughtDef obj;
			if (replacerList != null && !replacerList.Select((ThoughtReplacer tr) => tr.replacer).Contains(((Def)def).defName))
			{
				obj = DefDatabase<ThoughtDef>.GetNamedSilentFail(replacerList.FirstOrDefault((ThoughtReplacer tr) => GenText.EqualsIgnoreCase(tr.original, ((Def)def).defName))?.replacer ?? string.Empty);
				if (obj == null)
				{
					return def;
				}
			}
			else
			{
				obj = def;
			}
			return obj;
		}

		public ThoughtDef GetAteThought(ThingDef race, bool cannibal, bool ingredient)
		{
			return (ateThoughtSpecific?.FirstOrDefault((AteThought at) => at.raceList?.Contains(((Def)race).defName) ?? false) ?? ateThoughtGeneral)?.GetThought(cannibal, ingredient);
		}
	}
}
