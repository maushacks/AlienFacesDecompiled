using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace AlienRace
{
	public class PawnBioDef : Def
	{
		public string childhoodDef;

		public string adulthoodDef;

		public Backstory resolvedChildhood;

		public Backstory resolvedAdulthood;

		public GenderPossibility gender;

		public NameTriple name;

		public List<ThingDef> validRaces;

		public bool factionLeader;

		public List<string> forcedHediffs = new List<string>();

		public List<ThingDefCountRangeClass> forcedItems = new List<ThingDefCountRangeClass>();

		public unsafe override void ResolveReferences()
		{
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Invalid comparison between Unknown and I4
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_0087: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c2: Expected O, but got Unknown
			if (!BackstoryDatabase.TryGetWithIdentifier(childhoodDef, ref resolvedChildhood, true))
			{
				Log.Error("Error in " + base.defName + ": Childhood backstory not found", false);
			}
			if (!BackstoryDatabase.TryGetWithIdentifier(adulthoodDef, ref resolvedAdulthood, true))
			{
				Log.Error("Error in " + base.defName + ": Adulthood backstory not found", false);
			}
			((Editable)this).ResolveReferences();
			if ((int)resolvedAdulthood.slot == 1 && (int)resolvedChildhood.slot == 0)
			{
				PawnBio val = new PawnBio();
				((PawnBio)(long)(IntPtr)(void*)val).gender = gender;
				((PawnBio)(long)(IntPtr)(void*)val).name = name;
				((PawnBio)(long)(IntPtr)(void*)val).childhood = resolvedChildhood;
				((PawnBio)(long)(IntPtr)(void*)val).adulthood = resolvedAdulthood;
				((PawnBio)(long)(IntPtr)(void*)val).pirateKing = factionLeader;
				PawnBio val2 = (PawnBio)(object)val;
				if (resolvedAdulthood.spawnCategories.Count == 1 && resolvedAdulthood.spawnCategories[0] == "Trader")
				{
					resolvedAdulthood.spawnCategories.Add("Civil");
				}
				if (!val2.ConfigErrors().Any())
				{
					SolidBioDatabase.allBios.Add(val2);
				}
				else
				{
					Log.Error(base.defName + " has errors", false);
				}
			}
		}

		public PawnBioDef()
			: this()
		{
		}
	}
}
