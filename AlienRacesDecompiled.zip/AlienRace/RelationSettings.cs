using System.Collections.Generic;

namespace AlienRace
{
	public class RelationSettings
	{
		public float relationChanceModifierChild = 1f;

		public float relationChanceModifierExLover = 1f;

		public float relationChanceModifierExSpouse = 1f;

		public float relationChanceModifierFiance = 1f;

		public float relationChanceModifierLover = 1f;

		public float relationChanceModifierParent = 1f;

		public float relationChanceModifierSibling = 1f;

		public float relationChanceModifierSpouse = 1f;

		public List<RelationRenamer> renamer;
	}
}
