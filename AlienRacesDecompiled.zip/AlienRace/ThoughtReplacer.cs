namespace AlienRace
{
	public class ThoughtReplacer
	{
		public string original;

		public string replacer;
	}
}
