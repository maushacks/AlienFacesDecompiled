using JetBrains.Annotations;
using RimWorld;
using Verse;

namespace AlienRace
{
	[UsedImplicitly]
	public class Thought_XenophobiaVsAlien : Thought_SituationalSocial
	{
		public override float OpinionOffset()
		{
			return (((Thing)base.pawn).def != ((Thing)((Thought_SituationalSocial)this).OtherPawn()).def) ? ((base.pawn.story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) == 1) ? (-30) : ((((Thought_SituationalSocial)this).OtherPawn().story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) == 1) ? (-15) : 0)) : 0;
		}

		public Thought_XenophobiaVsAlien()
			: this()
		{
		}
	}
}
