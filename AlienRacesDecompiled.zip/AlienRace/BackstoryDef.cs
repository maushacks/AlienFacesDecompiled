using Harmony;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace AlienRace
{
	public class BackstoryDef : Def
	{
		public struct BackstoryDefSkillListItem
		{
			public string defName;

			public int amount;
		}

		public static HashSet<Backstory> checkBodyType = new HashSet<Backstory>();

		public string baseDescription;

		public BodyTypeDef bodyTypeGlobal;

		public BodyTypeDef bodyTypeMale;

		public BodyTypeDef bodyTypeFemale;

		public string title;

		public string titleFemale;

		public string titleShort;

		public string titleShortFemale;

		public BackstorySlot slot = (BackstorySlot)1;

		public bool shuffleable = true;

		public bool addToDatabase = true;

		public List<WorkTags> workAllows = new List<WorkTags>();

		public List<WorkTags> workDisables = new List<WorkTags>();

		public List<WorkTags> requiredWorkTags = new List<WorkTags>();

		public List<BackstoryDefSkillListItem> skillGains = new List<BackstoryDefSkillListItem>();

		public List<string> spawnCategories = new List<string>();

		public List<AlienTraitEntry> forcedTraits = new List<AlienTraitEntry>();

		public List<AlienTraitEntry> disallowedTraits = new List<AlienTraitEntry>();

		public float maleCommonality = 100f;

		public float femaleCommonality = 100f;

		public string linkedBackstory;

		public RelationSettings relationSettings = new RelationSettings();

		public List<string> forcedHediffs = new List<string>();

		public IntRange bioAgeRange;

		public IntRange chronoAgeRange;

		public List<ThingDefCountRangeClass> forcedItems = new List<ThingDefCountRangeClass>();

		public Backstory backstory;

		public bool CommonalityApproved(Gender g)
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			return (float)Rand.Range(0, 100) < (((int)g == 2) ? femaleCommonality : maleCommonality);
		}

		public bool Approved(Pawn p)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			if (CommonalityApproved(p.gender) && (bioAgeRange == default(IntRange) || (bioAgeRange.min < p.ageTracker.get_AgeBiologicalYears() && p.ageTracker.get_AgeBiologicalYears() < bioAgeRange.max)))
			{
				if (!(chronoAgeRange == default(IntRange)))
				{
					if (chronoAgeRange.min < p.ageTracker.get_AgeChronologicalYears())
					{
						return p.ageTracker.get_AgeChronologicalYears() < chronoAgeRange.max;
					}
					return false;
				}
				return true;
			}
			return false;
		}

		public unsafe override void ResolveReferences()
		{
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_0137: Unknown result type (might be due to invalid IL or missing references)
			//IL_0151: Unknown result type (might be due to invalid IL or missing references)
			//IL_0171: Unknown result type (might be due to invalid IL or missing references)
			//IL_0179: Unknown result type (might be due to invalid IL or missing references)
			//IL_017e: Unknown result type (might be due to invalid IL or missing references)
			//IL_018a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0197: Unknown result type (might be due to invalid IL or missing references)
			//IL_019c: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a6: Expected O, but got Unknown
			((Editable)this).ResolveReferences();
			if (addToDatabase && !BackstoryDatabase.allBackstories.ContainsKey(base.defName) && !GenText.NullOrEmpty(title) && !GenList.NullOrEmpty<string>((IList<string>)spawnCategories))
			{
				Backstory val = new Backstory();
				((Backstory)(long)(IntPtr)(void*)val).slot = slot;
				((Backstory)(long)(IntPtr)(void*)val).shuffleable = shuffleable;
				((Backstory)(long)(IntPtr)(void*)val).spawnCategories = spawnCategories;
				((Backstory)(long)(IntPtr)(void*)val).forcedTraits = (GenList.NullOrEmpty<AlienTraitEntry>((IList<AlienTraitEntry>)forcedTraits) ? null : forcedTraits.Where((AlienTraitEntry trait) => (float)Rand.Range(0, 100) < trait.chance).ToList().ConvertAll((AlienTraitEntry trait) => (TraitEntry)(object)new TraitEntry(TraitDef.Named(trait.defName), trait.degree)));
				((Backstory)(long)(IntPtr)(void*)val).disallowedTraits = (GenList.NullOrEmpty<AlienTraitEntry>((IList<AlienTraitEntry>)disallowedTraits) ? null : disallowedTraits.Where((AlienTraitEntry trait) => (float)Rand.Range(0, 100) < trait.chance).ToList().ConvertAll((AlienTraitEntry trait) => (TraitEntry)(object)new TraitEntry(TraitDef.Named(trait.defName), trait.degree)));
				WorkTags val2;
				int num;
				if (!GenList.NullOrEmpty<WorkTags>((IList<WorkTags>)workAllows))
				{
					val2 = ((Func<WorkTags>)delegate
					{
						//IL_0008: Unknown result type (might be due to invalid IL or missing references)
						//IL_0049: Unknown result type (might be due to invalid IL or missing references)
						WorkTags wt3 = (WorkTags)0;
						(from WorkTags tag in Enum.GetValues(typeof(WorkTags))
							where !workAllows.Contains(tag)
							select tag).ToList().ForEach(delegate(WorkTags tag)
						{
							//IL_0002: Unknown result type (might be due to invalid IL or missing references)
							//IL_0007: Unknown result type (might be due to invalid IL or missing references)
							//IL_0008: Unknown result type (might be due to invalid IL or missing references)
							//IL_0009: Unknown result type (might be due to invalid IL or missing references)
							wt3 = (WorkTags)(wt3 | tag);
						});
						return wt3;
					})();
					num = (int)val2;
				}
				else if (!GenList.NullOrEmpty<WorkTags>((IList<WorkTags>)workDisables))
				{
					val2 = ((Func<WorkTags>)delegate
					{
						//IL_0008: Unknown result type (might be due to invalid IL or missing references)
						//IL_0025: Unknown result type (might be due to invalid IL or missing references)
						WorkTags wt2 = (WorkTags)0;
						workDisables.ForEach(delegate(WorkTags tag)
						{
							//IL_0002: Unknown result type (might be due to invalid IL or missing references)
							//IL_0007: Unknown result type (might be due to invalid IL or missing references)
							//IL_0008: Unknown result type (might be due to invalid IL or missing references)
							//IL_0009: Unknown result type (might be due to invalid IL or missing references)
							wt2 = (WorkTags)(wt2 | tag);
						});
						return wt2;
					})();
					num = (int)val2;
				}
				else
				{
					num = 0;
				}
				((Backstory)(long)(IntPtr)(void*)val).workDisables = (WorkTags)num;
				((Backstory)(long)(IntPtr)(void*)val).identifier = base.defName;
				((Backstory)(long)(IntPtr)(void*)val).requiredWorkTags = ((Func<WorkTags>)delegate
				{
					//IL_0008: Unknown result type (might be due to invalid IL or missing references)
					//IL_0025: Unknown result type (might be due to invalid IL or missing references)
					WorkTags wt = (WorkTags)0;
					requiredWorkTags.ForEach(delegate(WorkTags tag)
					{
						//IL_0002: Unknown result type (might be due to invalid IL or missing references)
						//IL_0007: Unknown result type (might be due to invalid IL or missing references)
						//IL_0008: Unknown result type (might be due to invalid IL or missing references)
						//IL_0009: Unknown result type (might be due to invalid IL or missing references)
						wt = (WorkTags)(wt | tag);
					});
					return wt;
				})();
				backstory = (Backstory)(object)val;
				if (bodyTypeGlobal == null && bodyTypeFemale == null && bodyTypeMale == null)
				{
					checkBodyType.Add(backstory);
					bodyTypeGlobal = DefDatabase<BodyTypeDef>.GetRandom();
				}
				Traverse.Create(backstory).Field("bodyTypeGlobalResolved").SetValue(bodyTypeGlobal);
				Traverse.Create(backstory).Field("bodyTypeFemaleResolved").SetValue(bodyTypeFemale);
				Traverse.Create(backstory).Field("bodyTypeMaleResolved").SetValue(bodyTypeMale);
				Traverse.Create(backstory).Field("skillGains").SetValue(skillGains.ToDictionary((BackstoryDefSkillListItem i) => i.defName, (BackstoryDefSkillListItem i) => i.amount));
				UpdateTranslateableFields(this);
				backstory.ResolveReferences();
				backstory.PostLoad();
				backstory.identifier = base.defName;
				IEnumerable<string> source;
				if (!(source = backstory.ConfigErrors(false)).Any())
				{
					BackstoryDatabase.AddBackstory(backstory);
				}
				else
				{
					Log.Error(base.defName + " has errors:\n" + string.Join("\n", source.ToArray()), false);
				}
			}
		}

		internal static void UpdateTranslateableFields(BackstoryDef bs)
		{
			if (bs.backstory != null)
			{
				bs.backstory.baseDesc = (GenText.NullOrEmpty(bs.baseDescription) ? "Empty." : bs.baseDescription);
				bs.backstory.SetTitle(bs.title, bs.titleFemale);
				bs.backstory.SetTitleShort(GenText.NullOrEmpty(bs.titleShort) ? bs.backstory.title : bs.titleShort, GenText.NullOrEmpty(bs.titleShortFemale) ? bs.backstory.titleFemale : bs.titleShortFemale);
			}
		}

		public BackstoryDef()
			: this()
		{
		}//IL_0002: Unknown result type (might be due to invalid IL or missing references)

	}
}
