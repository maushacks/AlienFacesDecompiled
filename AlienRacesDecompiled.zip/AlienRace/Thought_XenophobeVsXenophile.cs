using JetBrains.Annotations;
using RimWorld;

namespace AlienRace
{
	[UsedImplicitly]
	public class Thought_XenophobeVsXenophile : Thought_SituationalSocial
	{
		public override float OpinionOffset()
		{
			if (base.pawn.story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) != 1)
			{
				return -15f;
			}
			return -25f;
		}

		public Thought_XenophobeVsXenophile()
			: this()
		{
		}
	}
}
