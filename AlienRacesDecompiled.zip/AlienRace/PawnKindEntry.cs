using System.Collections.Generic;

namespace AlienRace
{
	public class PawnKindEntry
	{
		public List<string> kindDefs = new List<string>();

		public float chance;
	}
}
