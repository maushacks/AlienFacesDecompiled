using RimWorld;
using System.Collections.Generic;
using Verse;

namespace AlienRace
{
	public class RaceRestrictionSettings
	{
		public bool onlyUseRaceRestrictedApparel;

		public List<string> apparelList = new List<string>();

		public List<string> whiteApparelList = new List<string>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> apparelRestrictionDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> apparelWhiteDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public List<ResearchProjectRestrictions> researchList;

		public bool onlyUseRaceRestrictedWeapons;

		public List<string> weaponList = new List<string>();

		public List<string> whiteWeaponList = new List<string>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> weaponRestrictionDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> weaponWhiteDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public bool onlyBuildRaceRestrictedBuildings;

		public List<string> buildingList = new List<string>();

		public List<string> whiteBuildingList = new List<string>();

		public static Dictionary<BuildableDef, List<ThingDef_AlienRace>> buildingRestrictionDict = new Dictionary<BuildableDef, List<ThingDef_AlienRace>>();

		public static Dictionary<BuildableDef, List<ThingDef_AlienRace>> buildingWhiteDict = new Dictionary<BuildableDef, List<ThingDef_AlienRace>>();

		public bool onlyDoRaceRestrictedRecipes;

		public List<string> recipeList = new List<string>();

		public List<string> whiteRecipeList = new List<string>();

		public static Dictionary<RecipeDef, List<ThingDef_AlienRace>> recipeRestrictionDict = new Dictionary<RecipeDef, List<ThingDef_AlienRace>>();

		public static Dictionary<RecipeDef, List<ThingDef_AlienRace>> recipeWhiteDict = new Dictionary<RecipeDef, List<ThingDef_AlienRace>>();

		public bool onlyDoRaceRastrictedPlants;

		public List<string> plantList = new List<string>();

		public List<string> whitePlantList = new List<string>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> plantRestrictionDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> plantWhiteDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public bool onlyGetRaceRestrictedTraits;

		public List<string> traitList = new List<string>();

		public List<string> whiteTraitList = new List<string>();

		public static Dictionary<TraitDef, List<ThingDef_AlienRace>> traitRestrictionDict = new Dictionary<TraitDef, List<ThingDef_AlienRace>>();

		public static Dictionary<TraitDef, List<ThingDef_AlienRace>> traitWhiteDict = new Dictionary<TraitDef, List<ThingDef_AlienRace>>();

		public bool onlyEatRaceRestrictedFood;

		public List<string> foodList = new List<string>();

		public List<string> whiteFoodList = new List<string>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> foodRestrictionDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> foodWhiteDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public bool onlyTameRaceRestrictedPets;

		public List<string> petList = new List<string>();

		public List<string> whitePetList = new List<string>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> tameRestrictionDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public static Dictionary<ThingDef, List<ThingDef_AlienRace>> tameWhiteDict = new Dictionary<ThingDef, List<ThingDef_AlienRace>>();

		public List<string> conceptList = new List<string>();

		public List<string> workGiverList = new List<string>();

		public static bool CanWear(ThingDef apparel, ThingDef race)
		{
			if ((apparelRestrictionDict.TryGetValue(apparel, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyUseRaceRestrictedApparel ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (apparelWhiteDict.TryGetValue(apparel, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanEquip(ThingDef weapon, ThingDef race)
		{
			if ((weaponRestrictionDict.TryGetValue(weapon, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyUseRaceRestrictedWeapons ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (weaponWhiteDict.TryGetValue(weapon, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanBuild(BuildableDef building, ThingDef race)
		{
			if ((buildingRestrictionDict.TryGetValue(building, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyBuildRaceRestrictedBuildings ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (buildingWhiteDict.TryGetValue(building, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanDoRecipe(RecipeDef recipe, ThingDef race)
		{
			if ((recipeRestrictionDict.TryGetValue(recipe, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyDoRaceRestrictedRecipes ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (recipeWhiteDict.TryGetValue(recipe, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanPlant(ThingDef plant, ThingDef race)
		{
			if ((plantRestrictionDict.TryGetValue(plant, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyDoRaceRastrictedPlants ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (plantWhiteDict.TryGetValue(plant, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanGetTrait(TraitDef trait, ThingDef race)
		{
			if ((traitRestrictionDict.TryGetValue(trait, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyGetRaceRestrictedTraits ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (traitWhiteDict.TryGetValue(trait, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanEat(ThingDef food, ThingDef race)
		{
			if ((foodRestrictionDict.TryGetValue(food, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyEatRaceRestrictedFood ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (foodWhiteDict.TryGetValue(food, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}

		public static bool CanTame(ThingDef pet, ThingDef race)
		{
			if ((tameRestrictionDict.TryGetValue(pet, out List<ThingDef_AlienRace> value) || ((race as ThingDef_AlienRace)?.alienRace.raceRestriction.onlyTameRaceRestrictedPets ?? false)) && (value == null || !value.Contains(race as ThingDef_AlienRace)))
			{
				if (tameWhiteDict.TryGetValue(pet, out value))
				{
					return value?.Contains(race as ThingDef_AlienRace) ?? false;
				}
				return false;
			}
			return true;
		}
	}
}
