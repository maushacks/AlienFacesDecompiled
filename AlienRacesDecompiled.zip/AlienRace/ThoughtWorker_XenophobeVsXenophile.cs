using JetBrains.Annotations;
using RimWorld;
using Verse;

namespace AlienRace
{
	[UsedImplicitly]
	public class ThoughtWorker_XenophobeVsXenophile : ThoughtWorker
	{
		protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn otherPawn)
		{
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			return ThoughtState.op_Implicit(p.get_RaceProps().get_Humanlike() && otherPawn.get_RaceProps().get_Humanlike() && p.story.traits.HasTrait(AlienDefOf.Xenophobia) && otherPawn.story.traits.HasTrait(AlienDefOf.Xenophobia) && p.story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) != otherPawn.story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) && RelationsUtility.PawnsKnowEachOther(p, otherPawn));
		}

		public ThoughtWorker_XenophobeVsXenophile()
			: this()
		{
		}
	}
}
