using JetBrains.Annotations;
using System.Collections.Generic;
using Verse;
using Verse.AI;

namespace AlienRace
{
	[UsedImplicitly]
	public class ThinkNode_ConditionalIsMemberOfRace : ThinkNode_Conditional
	{
		public List<string> races;

		protected override bool Satisfied(Pawn pawn)
		{
			return races.Contains(((Def)((Thing)pawn).def).defName);
		}

		public ThinkNode_ConditionalIsMemberOfRace()
			: this()
		{
		}
	}
}
