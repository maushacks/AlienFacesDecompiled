using System.Collections.Generic;

namespace AlienRace
{
	public class BackstoryTagItem
	{
		public List<string> backstories = new List<string>();

		public List<string> spawnCategories = new List<string>();
	}
}
