using RimWorld;
using System.Collections.Generic;
using UnityEngine;

namespace AlienRace
{
	public class GraphicPaths
	{
		public List<LifeStageDef> lifeStageDefs;

		public Vector2 customDrawSize = Vector2.get_one();

		public Vector2 customPortraitDrawSize = Vector2.get_one();

		public Vector2 customHeadDrawSize = Vector2.get_zero();

		public Vector2 customPortraitHeadDrawSize = Vector2.get_zero();

		public Vector2 headOffset = Vector2.get_zero();

		public const string VANILLA_HEAD_PATH = "Things/Pawn/Humanlike/Heads/";

		public const string VANILLA_SKELETON_PATH = "Things/Pawn/Humanlike/HumanoidDessicated";

		public string body = "Things/Pawn/Humanlike/Bodies/";

		public string head = "Things/Pawn/Humanlike/Heads/";

		public string skeleton = "Things/Pawn/Humanlike/HumanoidDessicated";

		public string skull = "Things/Pawn/Humanlike/Heads/None_Average_Skull";

		public string stump = "Things/Pawn/Humanlike/Heads/None_Average_Stump";
	}
}
