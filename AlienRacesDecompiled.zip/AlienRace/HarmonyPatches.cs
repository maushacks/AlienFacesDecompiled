using Harmony;
using Harmony.ILCopying;
using RimWorld;
using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.Grammar;

namespace AlienRace
{
	[StaticConstructorOnStartup]
	public static class HarmonyPatches
	{
		private static readonly Type patchType;

		private static BodyPartDef headPawnDef;

		private static HashSet<ThingStuffPair> apparelList;

		private static HashSet<ThingStuffPair> weaponList;

		private static HashSet<ThingDef> colonistRaces;

		private static int colonistRacesTick;

		private const int COLONIST_RACES_TICK_TIMER = 5000;

		private static PawnBioDef bioReference;

		private static readonly FactionDef noHairFaction;

		private static readonly FactionDef hairFaction;

		unsafe static HarmonyPatches()
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Expected O, but got Unknown
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Expected O, but got Unknown
			patchType = typeof(HarmonyPatches);
			FactionDef val = new FactionDef();
			((FactionDef)(long)(IntPtr)(void*)val).hairTags = new List<string>
			{
				"alienNoHair"
			};
			noHairFaction = (FactionDef)(object)val;
			hairFaction = (FactionDef)(object)new FactionDef();
			HarmonyInstance harmony = HarmonyInstance.Create("rimworld.erdelf.alien_race.main");
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_Child), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceChildPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_ExLover), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceExLoverPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_ExSpouse), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceExSpousePostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_Fiance), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceFiancePostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_Lover), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceLoverPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_Parent), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceParentPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_Sibling), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceSiblingPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationWorker_Spouse), "GenerationChance"), null, new HarmonyMethod(patchType, "GenerationChanceSpousePostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GeneratePawnRelations"), new HarmonyMethod(patchType, "GeneratePawnRelationsPrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRelationDef), "GetGenderSpecificLabel"), new HarmonyMethod(patchType, "GetGenderSpecificLabelPrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnBioAndNameGenerator), "TryGetRandomUnusedSolidBioFor"), null, new HarmonyMethod(patchType, "TryGetRandomUnusedSolidBioForPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnBioAndNameGenerator), "FillBackstorySlotShuffled"), new HarmonyMethod(patchType, "FillBackstoryInSlotShuffledPrefix"), null, new HarmonyMethod(patchType, "FillBackstoryInSlotShuffledTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_Researcher), "ShouldSkip"), null, new HarmonyMethod(patchType, "ShouldSkipResearchPostfix"));
			harmony.Patch(AccessTools.Method(typeof(MainTabWindow_Research), "ViewSize"), null, null, new HarmonyMethod(patchType, "ResearchScreenTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(MainTabWindow_Research), "DrawRightRect"), null, null, new HarmonyMethod(patchType, "ResearchScreenTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(GenConstruct), "CanConstruct"), null, new HarmonyMethod(patchType, "CanConstructPostfix"));
			harmony.Patch(AccessTools.Method(typeof(GameRules), "DesignatorAllowed"), null, new HarmonyMethod(patchType, "DesignatorAllowedPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Bill), "PawnAllowedToStartAnew"), null, new HarmonyMethod(patchType, "PawnAllowedToStartAnewPostfix"));
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_GrowerHarvest), "HasJobOnCell"), null, new HarmonyMethod(patchType, "HasJobOnCellHarvestPostfix"));
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_GrowerSow), "ExtraRequirements"), null, new HarmonyMethod(patchType, "ExtraRequirementsGrowerSowPostfix"));
			harmony.Patch(AccessTools.Method(typeof(FloatMenuMakerMap), "AddHumanlikeOrders"), null, new HarmonyMethod(patchType, "AddHumanlikeOrdersPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Pawn), "SetFaction"), null, new HarmonyMethod(patchType, "SetFactionPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Thing), "SetFactionDirect"), null, new HarmonyMethod(patchType, "SetFactionDirectPostfix"));
			harmony.Patch(AccessTools.Method(typeof(JobGiver_OptimizeApparel), "ApparelScoreGain"), null, new HarmonyMethod(patchType, "ApparelScoreGainPostFix"));
			harmony.Patch(AccessTools.Method(typeof(ThoughtUtility), "CanGetThought"), null, new HarmonyMethod(patchType, "CanGetThoughtPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Corpse), "ButcherProducts"), new HarmonyMethod(patchType, "ButcherProductsPrefix"));
			harmony.Patch(AccessTools.Method(typeof(FoodUtility), "ThoughtsFromIngesting"), null, new HarmonyMethod(patchType, "ThoughtsFromIngestingPostfix"));
			harmony.Patch(AccessTools.Method(typeof(MemoryThoughtHandler), "TryGainMemory", new Type[2]
			{
				typeof(Thought_Memory),
				typeof(Pawn)
			}), new HarmonyMethod(patchType, "TryGainMemoryPrefix"));
			harmony.Patch(AccessTools.Method(typeof(SituationalThoughtHandler), "TryCreateThought"), new HarmonyMethod(patchType, "TryCreateThoughtPrefix"));
			harmony.Patch(AccessTools.Method(AccessTools.TypeByName("AgeInjuryUtility"), "GenerateRandomOldAgeInjuries"), new HarmonyMethod(patchType, "GenerateRandomOldAgeInjuriesPrefix"));
			harmony.Patch(AccessTools.Method(AccessTools.TypeByName("AgeInjuryUtility"), "RandomHediffsToGainOnBirthday", new Type[2]
			{
				typeof(ThingDef),
				typeof(int)
			}), null, new HarmonyMethod(patchType, "RandomHediffsToGainOnBirthdayPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GenerateRandomAge"), new HarmonyMethod(patchType, "GenerateRandomAgePrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GenerateTraits"), new HarmonyMethod(patchType, "GenerateTraitsPrefix"), null, new HarmonyMethod(patchType, "GenerateTraitsTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(JobGiver_SatisfyChemicalNeed), "DrugValidator"), null, new HarmonyMethod(patchType, "DrugValidatorPostfix"));
			harmony.Patch(AccessTools.Method(typeof(CompDrug), "PostIngested"), null, new HarmonyMethod(patchType, "PostIngestedPostfix"));
			harmony.Patch(AccessTools.Method(typeof(AddictionUtility), "CanBingeOnNow"), null, new HarmonyMethod(patchType, "CanBingeNowPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GenerateBodyType"), null, new HarmonyMethod(patchType, "GenerateBodyTypePostfix"));
			harmony.Patch(AccessTools.Property(typeof(Pawn_StoryTracker), "SkinColor").GetGetMethod(), null, new HarmonyMethod(patchType, "SkinColorPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnHairChooser), "RandomHairDefFor"), new HarmonyMethod(patchType, "RandomHairDefForPrefix"));
			harmony.Patch(AccessTools.Method(typeof(Pawn_AgeTracker), "BirthdayBiological"), new HarmonyMethod(patchType, "BirthdayBiologicalPrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GeneratePawn", new Type[1]
			{
				typeof(PawnGenerationRequest)
			}), new HarmonyMethod(patchType, "GeneratePawnPrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGraphicSet), "ResolveAllGraphics"), new HarmonyMethod(patchType, "ResolveAllGraphicsPrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRenderer), "RenderPawnInternal", new Type[8]
			{
				typeof(Vector3),
				typeof(float),
				typeof(bool),
				typeof(Rot4),
				typeof(Rot4),
				typeof(RotDrawMode),
				typeof(bool),
				typeof(bool)
			}), null, null, new HarmonyMethod(patchType, "RenderPawnInternalTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(StartingPawnUtility), "NewGeneratedStartingPawn"), new HarmonyMethod(patchType, "NewGeneratedStartingPawnPrefix"));
			harmony.Patch(AccessTools.Method(typeof(PawnBioAndNameGenerator), "GiveAppropriateBioAndNameTo"), null, new HarmonyMethod(patchType, "GiveAppropriateBioAndNameToPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnBioAndNameGenerator), "GeneratePawnName"), new HarmonyMethod(patchType, "GeneratePawnNamePrefix"));
			harmony.Patch(AccessTools.Method(typeof(Page_ConfigureStartingPawns), "CanDoNext"), null, new HarmonyMethod(patchType, "CanDoNextStartPawnPostfix"));
			harmony.Patch(AccessTools.Method(typeof(GameInitData), "PrepForMapGen"), new HarmonyMethod(patchType, "PrepForMapGenPrefix"));
			harmony.Patch(AccessTools.Method(typeof(Pawn_RelationsTracker), "SecondaryLovinChanceFactor"), null, null, new HarmonyMethod(patchType, "SecondaryLovinChanceFactorTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(Pawn_RelationsTracker), "CompatibilityWith"), null, new HarmonyMethod(patchType, "CompatibilityWithPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Faction), "TryMakeInitialRelationsWith"), null, new HarmonyMethod(patchType, "TryMakeInitialRelationsWithPostfix"));
			harmony.Patch(AccessTools.Method(typeof(TraitSet), "GainTrait"), new HarmonyMethod(patchType, "GainTraitPrefix"));
			harmony.Patch(AccessTools.Method(typeof(TraderCaravanUtility), "GetTraderCaravanRole"), null, null, new HarmonyMethod(patchType, "GetTraderCaravanRoleTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(RestUtility), "CanUseBedEver"), null, new HarmonyMethod(patchType, "CanUseBedEverPostfix"));
			harmony.Patch(AccessTools.Property(typeof(Building_Bed), "AssigningCandidates").GetGetMethod(), null, new HarmonyMethod(patchType, "AssigningCandidatesPostfix"));
			harmony.Patch(AccessTools.Method(typeof(GrammarUtility), "RulesForPawn", new Type[3]
			{
				typeof(string),
				typeof(Pawn),
				typeof(Dictionary<string, string>)
			}), null, new HarmonyMethod(patchType, "RulesForPawnPostfix"));
			harmony.Patch(AccessTools.Method(typeof(RaceProperties), "CanEverEat", new Type[1]
			{
				typeof(ThingDef)
			}), null, new HarmonyMethod(patchType, "CanEverEat"));
			harmony.Patch(AccessTools.Method(typeof(Verb_MeleeAttackDamage), "DamageInfosToApply"), null, new HarmonyMethod(patchType, "DamageInfosToApplyPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnWeaponGenerator), "TryGenerateWeaponFor"), new HarmonyMethod(patchType, "TryGenerateWeaponForPrefix"), new HarmonyMethod(patchType, "TryGenerateWeaponForPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnApparelGenerator), "GenerateStartingApparelFor"), new HarmonyMethod(patchType, "GenerateStartingApparelForPrefix"), new HarmonyMethod(patchType, "GenerateStartingApparelForPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GenerateInitialHediffs"), null, new HarmonyMethod(patchType, "GenerateInitialHediffsPostfix"));
			harmony.Patch(typeof(HediffSet).GetMethods(AccessTools.all).First((MethodInfo mi) => GenAttribute.HasAttribute<CompilerGeneratedAttribute>((MemberInfo)mi) && mi.ReturnType == typeof(bool) && mi.GetParameters().First().ParameterType == typeof(BodyPartRecord)), null, new HarmonyMethod(patchType, "HasHeadPostfix"));
			harmony.Patch(AccessTools.Property(typeof(HediffSet), "HasHead").GetGetMethod(), new HarmonyMethod(patchType, "HasHeadPrefix"));
			harmony.Patch(AccessTools.Method(typeof(Pawn_AgeTracker), "RecalculateLifeStageIndex"), null, new HarmonyMethod(patchType, "RecalculateLifeStageIndexPostfix"));
			harmony.Patch(GenCollection.MaxBy<MethodInfo, int>((IEnumerable<MethodInfo>)GenCollection.MaxBy<Type, int>((IEnumerable<Type>)typeof(FactionGenerator).GetNestedTypes(BindingFlags.Instance | BindingFlags.NonPublic), (Func<Type, int>)((Type t) => t.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic).Length)).GetMethods(BindingFlags.Instance | BindingFlags.NonPublic), (Func<MethodInfo, int>)delegate(MethodInfo mi)
			{
				MethodBody methodBody = mi.GetMethodBody();
				return (methodBody == null) ? (-1) : methodBody.GetILAsByteArray().Length;
			}), null, new HarmonyMethod(patchType, "EnsureRequiredEnemiesPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Faction), "FactionTick"), null, null, new HarmonyMethod(patchType, "FactionTickTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(Designator), "CanDesignateThing"), null, new HarmonyMethod(patchType, "CanDesignateThingTamePostfix"));
			harmony.Patch(AccessTools.Method(typeof(WorkGiver_InteractAnimal), "CanInteractWithAnimal"), null, new HarmonyMethod(patchType, "CanInteractWithAnimalPostfix"));
			harmony.Patch(AccessTools.Method(typeof(PawnRenderer), "BaseHeadOffsetAt"), null, new HarmonyMethod(patchType, "BaseHeadOffsetAtPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Pawn_HealthTracker), "CheckForStateChange"), null, new HarmonyMethod(patchType, "CheckForStateChangePostfix"));
			harmony.Patch(AccessTools.Method(typeof(ApparelProperties), "GetInterferingBodyPartGroups"), null, null, new HarmonyMethod(patchType, "GetInterferingBodyPartGroupsTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(PawnGenerator), "GenerateGearFor"), null, new HarmonyMethod(patchType, "GenerateGearForPostfix"));
			harmony.Patch(AccessTools.Method(typeof(Pawn), "ChangeKind"), new HarmonyMethod(patchType, "ChangeKindPrefix"));
			harmony.Patch(AccessTools.Method(typeof(EditWindow_TweakValues), "DoWindowContents"), null, null, new HarmonyMethod(patchType, "TweakValuesTranspiler"));
			harmony.Patch(AccessTools.Method(typeof(PawnBioAndNameGenerator), "GetBackstoryCategoriesFor"), null, null, new HarmonyMethod(patchType, "GetBackstoryCategoriesForTranspiler"));
			HarmonyMethod transpiler = new HarmonyMethod(patchType, "MisandryMisogynyTranspiler");
			harmony.Patch(AccessTools.Method(typeof(ThoughtWorker_Woman), "CurrentSocialStateInternal"), null, null, transpiler);
			harmony.Patch(AccessTools.Method(typeof(ThoughtWorker_Man), "CurrentSocialStateInternal"), null, null, transpiler);
			DefDatabase<ThingDef_AlienRace>.get_AllDefsListForReading().ForEach(delegate(ThingDef_AlienRace ar)
			{
				foreach (ThoughtDef item in from td in ((IEnumerable<string>)ar.alienRace.thoughtSettings.restrictedThoughts).Select((Func<string, ThoughtDef>)DefDatabase<ThoughtDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!ThoughtSettings.thoughtRestrictionDict.ContainsKey(item))
					{
						ThoughtSettings.thoughtRestrictionDict.Add(item, new List<ThingDef_AlienRace>());
					}
					ThoughtSettings.thoughtRestrictionDict[item].Add(ar);
				}
				foreach (ThingDef item2 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.apparelList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.apparelRestrictionDict.ContainsKey(item2))
					{
						RaceRestrictionSettings.apparelRestrictionDict.Add(item2, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.apparelRestrictionDict[item2].Add(ar);
				}
				foreach (ThingDef item3 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whiteApparelList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.apparelWhiteDict.ContainsKey(item3))
					{
						RaceRestrictionSettings.apparelWhiteDict.Add(item3, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.apparelWhiteDict[item3].Add(ar);
				}
				foreach (ThingDef item4 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.weaponList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.weaponRestrictionDict.ContainsKey(item4))
					{
						RaceRestrictionSettings.weaponRestrictionDict.Add(item4, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.weaponRestrictionDict[item4].Add(ar);
				}
				foreach (ThingDef item5 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whiteWeaponList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.weaponWhiteDict.ContainsKey(item5))
					{
						RaceRestrictionSettings.weaponWhiteDict.Add(item5, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.weaponWhiteDict[item5].Add(ar);
				}
				foreach (ThingDef item6 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.buildingList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.buildingRestrictionDict.ContainsKey((BuildableDef)(object)item6))
					{
						RaceRestrictionSettings.buildingRestrictionDict.Add((BuildableDef)(object)item6, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.buildingRestrictionDict[(BuildableDef)(object)item6].Add(ar);
				}
				foreach (ThingDef item7 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whiteBuildingList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.buildingWhiteDict.ContainsKey((BuildableDef)(object)item7))
					{
						RaceRestrictionSettings.buildingWhiteDict.Add((BuildableDef)(object)item7, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.buildingWhiteDict[(BuildableDef)(object)item7].Add(ar);
				}
				foreach (RecipeDef item8 in from rp in ((IEnumerable<string>)ar.alienRace.raceRestriction.recipeList).Select((Func<string, RecipeDef>)DefDatabase<RecipeDef>.GetNamedSilentFail)
					where rp != null
					select rp)
				{
					if (!RaceRestrictionSettings.recipeRestrictionDict.ContainsKey(item8))
					{
						RaceRestrictionSettings.recipeRestrictionDict.Add(item8, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.recipeRestrictionDict[item8].Add(ar);
				}
				foreach (RecipeDef item9 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whiteRecipeList).Select((Func<string, RecipeDef>)DefDatabase<RecipeDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.recipeWhiteDict.ContainsKey(item9))
					{
						RaceRestrictionSettings.recipeWhiteDict.Add(item9, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.recipeWhiteDict[item9].Add(ar);
				}
				foreach (ThingDef item10 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.plantList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.plantRestrictionDict.ContainsKey(item10))
					{
						RaceRestrictionSettings.plantRestrictionDict.Add(item10, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.plantRestrictionDict[item10].Add(ar);
				}
				foreach (ThingDef item11 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whitePlantList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.plantWhiteDict.ContainsKey(item11))
					{
						RaceRestrictionSettings.plantWhiteDict.Add(item11, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.plantWhiteDict[item11].Add(ar);
				}
				foreach (TraitDef item12 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.traitList).Select((Func<string, TraitDef>)DefDatabase<TraitDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.traitRestrictionDict.ContainsKey(item12))
					{
						RaceRestrictionSettings.traitRestrictionDict.Add(item12, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.traitRestrictionDict[item12].Add(ar);
				}
				foreach (TraitDef item13 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whiteTraitList).Select((Func<string, TraitDef>)DefDatabase<TraitDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.traitWhiteDict.ContainsKey(item13))
					{
						RaceRestrictionSettings.traitWhiteDict.Add(item13, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.traitWhiteDict[item13].Add(ar);
				}
				foreach (ThingDef item14 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.foodList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.foodRestrictionDict.ContainsKey(item14))
					{
						RaceRestrictionSettings.foodRestrictionDict.Add(item14, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.foodRestrictionDict[item14].Add(ar);
				}
				foreach (ThingDef item15 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whiteFoodList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.foodWhiteDict.ContainsKey(item15))
					{
						RaceRestrictionSettings.foodWhiteDict.Add(item15, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.foodWhiteDict[item15].Add(ar);
				}
				foreach (ThingDef item16 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.petList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.tameRestrictionDict.ContainsKey(item16))
					{
						RaceRestrictionSettings.tameRestrictionDict.Add(item16, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.tameRestrictionDict[item16].Add(ar);
				}
				foreach (ThingDef item17 in from td in ((IEnumerable<string>)ar.alienRace.raceRestriction.whitePetList).Select((Func<string, ThingDef>)DefDatabase<ThingDef>.GetNamedSilentFail)
					where td != null
					select td)
				{
					if (!RaceRestrictionSettings.tameWhiteDict.ContainsKey(item17))
					{
						RaceRestrictionSettings.tameWhiteDict.Add(item17, new List<ThingDef_AlienRace>());
					}
					RaceRestrictionSettings.tameWhiteDict[item17].Add(ar);
				}
				ThingCategoryDefOf.CorpsesHumanlike.childThingDefs.Remove(((ThingDef)ar).race.corpseDef);
				((ThingDef)ar).race.corpseDef.thingCategories = new List<ThingCategoryDef>
				{
					AlienDefOf.alienCorpseCategory
				};
				AlienDefOf.alienCorpseCategory.childThingDefs.Add(((ThingDef)ar).race.corpseDef);
				ar.alienRace.generalSettings.alienPartGenerator.GenerateMeshsAndMeshPools();
				if (ar.alienRace.generalSettings.humanRecipeImport)
				{
					(((ThingDef)ar).recipes ?? (((ThingDef)ar).recipes = new List<RecipeDef>())).AddRange(ThingDefOf.Human.recipes.Where((RecipeDef rd) => !rd.targetsBodyPart || GenList.NullOrEmpty<BodyPartDef>((IList<BodyPartDef>)rd.appliedOnFixedBodyParts) || GenCollection.Any<BodyPartDef>(rd.appliedOnFixedBodyParts, (Predicate<BodyPartDef>)((BodyPartDef bpd) => GenCollection.Any<BodyPartRecord>(((ThingDef)ar).race.body.get_AllParts(), (Predicate<BodyPartRecord>)((BodyPartRecord bpr) => bpr.def == bpd))))));
					DefDatabase<RecipeDef>.get_AllDefsListForReading().ForEach(delegate(RecipeDef rd)
					{
						if (rd.recipeUsers?.Contains(ThingDefOf.Human) ?? false)
						{
							rd.recipeUsers.Add((ThingDef)(object)ar);
						}
						ThingFilter defaultIngredientFilter = rd.defaultIngredientFilter;
						if (defaultIngredientFilter != null && !defaultIngredientFilter.Allows(ThingDefOf.Meat_Human))
						{
							rd.defaultIngredientFilter.SetAllow(((ThingDef)ar).race.meatDef, false);
						}
					});
					GenList.RemoveDuplicates<RecipeDef>(((ThingDef)ar).recipes);
				}
				ar.alienRace.raceRestriction?.workGiverList?.ForEach(delegate(string wgd)
				{
					WorkGiverDef namedSilentFail = DefDatabase<WorkGiverDef>.GetNamedSilentFail(wgd);
					if (namedSilentFail != null)
					{
						harmony.Patch(AccessTools.Method(namedSilentFail.giverClass, "JobOnThing"), null, new HarmonyMethod(patchType, "GenericJobOnThingPostfix"));
						MethodInfo methodInfo2 = AccessTools.Method(namedSilentFail.giverClass, "HasJobOnThing");
						if (methodInfo2 != null)
						{
							harmony.Patch(methodInfo2, null, new HarmonyMethod(patchType, "GenericHasJobOnThingPostfix"));
						}
					}
				});
			});
			harmony.Patch(AccessTools.Method(typeof(ILInstruction), "GetSize"), null, null, new HarmonyMethod(patchType, "HarmonySizeBugFix"));
			FieldInfo bodyInfo = AccessTools.Field(typeof(RaceProperties), "body");
			MethodInfo methodInfo = AccessTools.Method(patchType, "ReplacedBody");
			HarmonyMethod transpiler2 = new HarmonyMethod(patchType, "BodyReferenceTranspiler");
			ILGenerator iLGenerator = new DynamicMethod("ScanMethod", typeof(void), Type.EmptyTypes).GetILGenerator();
			foreach (MethodInfo item18 in (from t in typeof(LogEntry).Assembly.GetTypes()
				where (!t.IsAbstract || t.IsSealed) && !typeof(Delegate).IsAssignableFrom(t) && !t.IsGenericType && !GenAttribute.HasAttribute<CompilerGeneratedAttribute>((MemberInfo)t)
				select t).SelectMany((Type t) => from mi in t.GetMethods(AccessTools.all).Concat(t.GetProperties(AccessTools.all).SelectMany((PropertyInfo pi) => new List<MethodInfo>
				{
					pi.GetGetMethod(nonPublic: true),
					pi.GetGetMethod(nonPublic: false),
					pi.GetSetMethod(nonPublic: true),
					pi.GetSetMethod(nonPublic: false)
				}))
				where mi != null && !mi.IsAbstract && mi.DeclaringType == t && !mi.IsGenericMethod && !GenAttribute.HasAttribute<DllImportAttribute>((MemberInfo)mi)
				select mi))
			{
				List<ILInstruction> instructions = PatchFunctions.GetInstructions(iLGenerator, item18);
				if (item18 != methodInfo && GenCollection.Any<ILInstruction>(instructions, (Predicate<ILInstruction>)((ILInstruction il) => il.operand == bodyInfo)))
				{
					harmony.Patch(item18, null, null, transpiler2);
				}
			}
			MethodInfo postureInfo = AccessTools.Method(typeof(PawnUtility), "GetPosture");
			foreach (MethodInfo item19 in from mi in typeof(PawnRenderer).GetMethods(AccessTools.all).Concat(typeof(PawnRenderer).GetProperties(AccessTools.all).SelectMany((PropertyInfo pi) => new List<MethodInfo>
				{
					pi.GetGetMethod(nonPublic: true),
					pi.GetGetMethod(nonPublic: false),
					pi.GetSetMethod(nonPublic: true),
					pi.GetSetMethod(nonPublic: false)
				}))
				where mi != null && mi.DeclaringType == typeof(PawnRenderer) && !mi.IsGenericMethod
				select mi)
			{
				if (GenCollection.Any<ILInstruction>(PatchFunctions.GetInstructions(iLGenerator, item19), (Predicate<ILInstruction>)((ILInstruction il) => il.operand == postureInfo)))
				{
					harmony.Patch(item19, null, null, new HarmonyMethod(patchType, "PostureTranspiler"));
				}
			}
			Log.Message($"Alien race successfully completed {(from mb in harmony.GetPatchedMethods()
				select harmony.GetPatchInfo(mb)).SelectMany((Patches p) => p.Prefixes.Concat(p.Postfixes).Concat(p.Transpilers)).Count((Patch p) => p.owner == harmony.Id)} patches with harmony.", false);
			DefDatabase<HairDef>.GetNamed("Shaved", true).hairTags.Add("alienNoHair");
			foreach (BackstoryDef allDef in DefDatabase<BackstoryDef>.get_AllDefs())
			{
				BackstoryDef.UpdateTranslateableFields(allDef);
			}
		}

		public static IEnumerable<CodeInstruction> MisandryMisogynyTranspiler(IEnumerable<CodeInstruction> instructions, ILGenerator ilg)
		{
			List<CodeInstruction> list = instructions.ToList();
			FieldInfo defInfo = AccessTools.Field(typeof(Thing), "def");
			bool yield = true;
			foreach (CodeInstruction instruction in list)
			{
				if (yield && instruction.operand == defInfo)
				{
					yield = false;
				}
				if (yield)
				{
					yield return instruction;
				}
				if (!yield && instruction.opcode == OpCodes.Ldarg_2)
				{
					yield = true;
				}
			}
		}

		public static IEnumerable<CodeInstruction> GetBackstoryCategoriesForTranspiler(IEnumerable<CodeInstruction> instructions, ILGenerator ilg)
		{
			List<CodeInstruction> instructionList = instructions.ToList();
			for (int index = 0; index < instructionList.Count; index++)
			{
				CodeInstruction instruction = instructionList[index];
				if (instruction.opcode == OpCodes.Ldc_I4_0)
				{
					Label label3 = ilg.DefineLabel();
					Label label2 = ilg.DefineLabel();
					object breakLabel = instructionList[index - 1].operand;
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Pawn), "def"));
					yield return new CodeInstruction(OpCodes.Isinst, typeof(ThingDef_AlienRace));
					yield return new CodeInstruction(OpCodes.Brfalse, label3);
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Pawn), "def"));
					yield return new CodeInstruction(OpCodes.Castclass, typeof(ThingDef_AlienRace));
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(ThingDef_AlienRace), "alienRace"));
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(ThingDef_AlienRace.AlienSettings), "generalSettings"));
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(GeneralSettings), "useOnlyPawnkindBackstories"));
					yield return new CodeInstruction(OpCodes.Brtrue, breakLabel);
					yield return new CodeInstruction(OpCodes.Ldarg_0)
					{
						labels = new List<Label>
						{
							label3
						}
					};
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Pawn), "kindDef"));
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(PawnKindDef), "GetModExtension").MakeGenericMethod(typeof(Info)));
					yield return new CodeInstruction(OpCodes.Brfalse, label2);
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Pawn), "kindDef"));
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(PawnKindDef), "GetModExtension").MakeGenericMethod(typeof(Info)));
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(Info), "useOnlyPawnkindBackstories"));
					yield return new CodeInstruction(OpCodes.Brtrue, breakLabel);
					instruction.labels.Add(label2);
				}
				yield return instruction;
			}
		}

		public static IEnumerable<CodeInstruction> TweakValuesTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			MethodInfo endScrollInfo = AccessTools.Method(typeof(Widgets), "EndScrollView");
			MethodInfo countInfo = AccessTools.Property(AccessTools.Field(typeof(EditWindow_TweakValues), "tweakValueFields").FieldType, "Count").GetGetMethod();
			foreach (CodeInstruction instruction in instructions)
			{
				if (instruction.operand == endScrollInfo)
				{
					yield return new CodeInstruction(OpCodes.Ldloc_2)
					{
						labels = GenList.ListFullCopy<Label>(instruction.labels)
					};
					instruction.labels.Clear();
					yield return new CodeInstruction(OpCodes.Ldloc_3);
					yield return new CodeInstruction(OpCodes.Ldloc_S, 4);
					yield return new CodeInstruction(OpCodes.Ldloc_S, 5);
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "TweakValuesInstanceBased"));
				}
				yield return instruction;
				if (instruction.operand == countInfo)
				{
					yield return new CodeInstruction(OpCodes.Ldc_I4, DefDatabase<ThingDef_AlienRace>.get_AllDefs().SelectMany((ThingDef_AlienRace ar) => ar.alienRace.generalSettings.alienPartGenerator.bodyAddons).Sum((AlienPartGenerator.BodyAddon ba) => new List<AlienPartGenerator.RotationOffset>
					{
						ba.offsets.east,
						ba.offsets.west,
						ba.offsets.north,
						ba.offsets.south
					}.Sum((AlienPartGenerator.RotationOffset ro) => (ro.bodyTypes?.Count ?? 0) * 2 + (ro.crownTypes?.Count ?? 0) * 2) + 1) + 1);
					yield return new CodeInstruction(OpCodes.Add);
				}
			}
		}

		public static void TweakValuesInstanceBased(Rect rect2, Rect rect3, Rect rect4, Rect rect5)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_018b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0190: Unknown result type (might be due to invalid IL or missing references)
			//IL_024c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0251: Unknown result type (might be due to invalid IL or missing references)
			Rect rect8 = rect2;
			Rect rect9 = rect3;
			Rect rect7 = rect4;
			Rect rect6 = rect5;
			NextLine();
			foreach (ThingDef_AlienRace allDef in DefDatabase<ThingDef_AlienRace>.get_AllDefs())
			{
				string label2 = ((Def)allDef).get_LabelCap();
				foreach (AlienPartGenerator.BodyAddon bodyAddon in allDef.alienRace.generalSettings.alienPartGenerator.bodyAddons)
				{
					string label3Addons = Path.GetFileName(bodyAddon.path) + ".";
					List<AlienPartGenerator.RotationOffset> list = new List<AlienPartGenerator.RotationOffset>
					{
						bodyAddon.offsets.north,
						bodyAddon.offsets.south,
						bodyAddon.offsets.west,
						bodyAddon.offsets.east
					};
					string label3Rotation;
					string label3Type2;
					string label3Type;
					for (int i = 0; i < list.Count; i++)
					{
						AlienPartGenerator.RotationOffset rotationOffset = list[i];
						switch (i)
						{
						case 0:
							label3Rotation = "north.";
							break;
						case 1:
							label3Rotation = "south.";
							break;
						case 2:
							label3Rotation = "west.";
							break;
						default:
							label3Rotation = "east.";
							break;
						}
						if (!GenList.NullOrEmpty<AlienPartGenerator.BodyTypeOffset>((IList<AlienPartGenerator.BodyTypeOffset>)rotationOffset.bodyTypes))
						{
							foreach (AlienPartGenerator.BodyTypeOffset bodyType in rotationOffset.bodyTypes)
							{
								label3Type2 = ((Def)bodyType.bodyType).defName + ".";
								Vector2 offset = bodyType.offset;
								float x2 = offset.x;
								float y = offset.y;
								bodyType.offset.x = WriteAddonLine(x2, x: true);
								NextLine();
								bodyType.offset.y = WriteAddonLine(y, x: false);
								NextLine();
								float WriteAddonLine(float value, bool x)
								{
									return WriteLine(value, label3Rotation + label3Type2 + (x ? "x" : "y"));
								}
							}
						}
						if (!GenList.NullOrEmpty<AlienPartGenerator.CrownTypeOffset>((IList<AlienPartGenerator.CrownTypeOffset>)rotationOffset.crownTypes))
						{
							foreach (AlienPartGenerator.CrownTypeOffset crownType in rotationOffset.crownTypes)
							{
								label3Type = crownType.crownType + ".";
								Vector2 offset2 = crownType.offset;
								float x3 = offset2.x;
								float y2 = offset2.y;
								crownType.offset.x = WriteAddonLine(x3, x: true);
								NextLine();
								crownType.offset.y = WriteAddonLine(y2, x: false);
								NextLine();
								float WriteAddonLine(float value, bool x)
								{
									return WriteLine(value, label3Rotation + label3Type + (x ? "x" : "y"));
								}
							}
						}
					}
					bodyAddon.layerOffset = WriteLine(bodyAddon.layerOffset, "layerOffset");
					NextLine();
					float WriteLine(float value, string label)
					{
						Widgets.Label(rect8, label2);
						Widgets.Label(rect9, label3Addons + label);
						float num = Widgets.HorizontalSlider(rect6, value, -1f, 1f, false, (string)null, (string)null, (string)null, -1f);
						if ((double)Math.Abs(num - value) > 0.0001)
						{
							GUI.set_color(Color.get_red());
							Widgets.Label(rect7, $"{value} -> {num}");
							GUI.set_color(Color.get_white());
						}
						else
						{
							Widgets.Label(rect7, value.ToString(CultureInfo.InvariantCulture));
						}
						return num;
					}
				}
			}
			void NextLine()
			{
				ref Rect reference = ref rect8;
				((Rect)(ref reference)).set_y(((Rect)(ref reference)).get_y() + ((Rect)(ref rect8)).get_height());
				ref Rect reference2 = ref rect9;
				((Rect)(ref reference2)).set_y(((Rect)(ref reference2)).get_y() + ((Rect)(ref rect8)).get_height());
				ref Rect reference3 = ref rect7;
				((Rect)(ref reference3)).set_y(((Rect)(ref reference3)).get_y() + ((Rect)(ref rect8)).get_height());
				ref Rect reference4 = ref rect6;
				((Rect)(ref reference4)).set_y(((Rect)(ref reference4)).get_y() + ((Rect)(ref rect8)).get_height());
			}
		}

		public static IEnumerable<CodeInstruction> HarmonySizeBugFix(IEnumerable<CodeInstruction> instructions)
		{
			foreach (CodeInstruction instruction in instructions)
			{
				if (instruction.opcode == OpCodes.Castclass)
				{
					instruction.operand = typeof(IEnumerable<object>);
				}
				yield return instruction;
			}
		}

		public static IEnumerable<CodeInstruction> PostureTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			MethodInfo postureInfo = AccessTools.Method(typeof(PawnUtility), "GetPosture");
			CodeInstruction[] array = (instructions as CodeInstruction[]) ?? instructions.ToArray();
			CodeInstruction[] array2 = array;
			foreach (CodeInstruction codeInstruction in array2)
			{
				if (codeInstruction.opcode == OpCodes.Call && codeInstruction.operand == postureInfo)
				{
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "PostureTweak"));
				}
				else
				{
					yield return codeInstruction;
				}
			}
		}

		public static PawnPosture PostureTweak(Pawn pawn)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0050: Unknown result type (might be due to invalid IL or missing references)
			PawnPosture posture = PawnUtility.GetPosture(pawn);
			if ((int)posture != 0)
			{
				ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
				if (thingDef_AlienRace != null && !thingDef_AlienRace.alienRace.generalSettings.canLayDown)
				{
					Building_Bed obj = RestUtility.CurrentBed(pawn);
					if (obj == null || !GenText.EqualsIgnoreCase(((Def)((Thing)obj).def).defName, "ET_Bed"))
					{
						return (PawnPosture)0;
					}
				}
			}
			return posture;
		}

		public static IEnumerable<CodeInstruction> BodyReferenceTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			FieldInfo bodyInfo = AccessTools.Field(typeof(RaceProperties), "body");
			FieldInfo propsInfo = AccessTools.Field(typeof(ThingDef), "race");
			FieldInfo defInfo = AccessTools.Field(typeof(Thing), "def");
			List<CodeInstruction> instructionList = instructions.ToList();
			for (int i = 0; i < instructionList.Count; i++)
			{
				CodeInstruction codeInstruction = instructionList[i];
				if (i < instructionList.Count - 2 && instructionList[i + 2].operand == bodyInfo && instructionList[i + 1].operand == propsInfo && codeInstruction.operand == defInfo)
				{
					codeInstruction = new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "ReplacedBody"));
					i += 2;
				}
				if (i < instructionList.Count - 1 && instructionList[i + 1].operand == bodyInfo && codeInstruction.operand == defInfo)
				{
					codeInstruction = new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "ReplacedBody"));
					i++;
				}
				yield return codeInstruction;
			}
		}

		public static BodyDef ReplacedBody(Pawn pawn)
		{
			if (!(((Thing)pawn).def is ThingDef_AlienRace))
			{
				return pawn.get_RaceProps().body;
			}
			return (pawn.ageTracker.get_CurLifeStageRace() as LifeStageAgeAlien)?.body ?? pawn.get_RaceProps().body;
		}

		public static bool ChangeKindPrefix(Pawn __instance, PawnKindDef newKindDef)
		{
			if (__instance.kindDef != PawnKindDefOf.WildMan)
			{
				return newKindDef == PawnKindDefOf.WildMan;
			}
			return true;
		}

		public static void GenerateGearForPostfix(Pawn pawn)
		{
			Pawn_StoryTracker story = pawn.story;
			if (story != null)
			{
				(from bs in story.get_AllBackstories()?.Select((Backstory bs) => DefDatabase<BackstoryDef>.GetNamedSilentFail(bs.identifier))
					where bs != null
					select bs).SelectMany((BackstoryDef bd) => bd.forcedItems).Concat(bioReference?.forcedItems ?? new List<ThingDefCountRangeClass>(0)).Do(delegate(ThingDefCountRangeClass tdcrc)
				{
					for (int i = 0; i < ((IntRange)(ref tdcrc.countRange)).get_RandomInRange(); i++)
					{
						Pawn_InventoryTracker inventory = pawn.inventory;
						if (inventory != null)
						{
							inventory.TryAddItemNotForSale(ThingMaker.MakeThing(tdcrc.thingDef, GenStuff.RandomStuffFor(tdcrc.thingDef)));
						}
					}
				});
			}
		}

		public static IEnumerable<CodeInstruction> GetInterferingBodyPartGroupsTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			bool done = false;
			foreach (CodeInstruction instruction in instructions)
			{
				if (!done && instruction.opcode == OpCodes.Call)
				{
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Property(typeof(DefDatabase<BodyDef>), "DefCount").GetGetMethod());
					done = true;
				}
				else
				{
					yield return instruction;
				}
			}
		}

		public static void CheckForStateChangePostfix(Pawn_HealthTracker __instance)
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Invalid comparison between Unknown and I4
			Pawn value = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
			if ((int)Current.get_ProgramState() == 2 && ((Thing)value).get_Spawned() && ((Thing)value).def is ThingDef_AlienRace)
			{
				value.get_Drawer().renderer.graphics.ResolveAllGraphics();
			}
		}

		public static void BaseHeadOffsetAtPostfix(PawnRenderer __instance, ref Vector3 __result)
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_0046: Unknown result type (might be due to invalid IL or missing references)
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			Pawn value = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
			Vector2 val = (((Thing)value).def as ThingDef_AlienRace)?.alienRace.graphicPaths.GetCurrentGraphicPath(value.ageTracker.get_CurLifeStage()).headOffset ?? Vector2.get_zero();
			__result.x += val.x;
			__result.z += val.y;
		}

		public static void CanInteractWithAnimalPostfix(ref bool __result, Pawn pawn, Pawn animal)
		{
			__result = (__result && RaceRestrictionSettings.CanTame(((Thing)animal).def, ((Thing)pawn).def));
		}

		public static void CanDesignateThingTamePostfix(Designator __instance, ref bool __result, Thing t)
		{
			if (__result && __instance is Designator_Build)
			{
				__result = colonistRaces.Any((ThingDef td) => RaceRestrictionSettings.CanTame(t.def, td));
			}
		}

		public static IEnumerable<CodeInstruction> FactionTickTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			foreach (CodeInstruction instruction in instructions)
			{
				yield return instruction;
				if (!(instruction.opcode != OpCodes.Beq))
				{
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "FactionTickFactionRelationCheck"));
					yield return new CodeInstruction(OpCodes.Brfalse, instruction.operand);
				}
			}
		}

		private static bool FactionTickFactionRelationCheck(Faction f)
		{
			FactionDef player = Faction.get_OfPlayerSilentFail()?.def ?? Find.get_GameInitData().playerFaction.def;
			return !DefDatabase<ThingDef_AlienRace>.get_AllDefs().Any(delegate(ThingDef_AlienRace ar)
			{
				if (f.def?.basicMemberKind?.race == ar)
				{
					bool? obj;
					if (ar == null)
					{
						obj = null;
					}
					else
					{
						GeneralSettings generalSettings = ar.alienRace.generalSettings;
						if (generalSettings == null)
						{
							obj = null;
						}
						else
						{
							List<FactionRelationSettings> factionRelations = generalSettings.factionRelations;
							obj = ((factionRelations != null) ? new bool?(GenCollection.Any<FactionRelationSettings>(factionRelations, (Predicate<FactionRelationSettings>)((FactionRelationSettings frs) => frs.factions?.Contains(((Def)player).defName) ?? false))) : null);
						}
					}
					bool? flag = obj;
					if (flag.GetValueOrDefault())
					{
						return true;
					}
				}
				if (player.basicMemberKind?.race == ar)
				{
					bool? obj2;
					if (ar == null)
					{
						obj2 = null;
					}
					else
					{
						GeneralSettings generalSettings2 = ar.alienRace.generalSettings;
						if (generalSettings2 == null)
						{
							obj2 = null;
						}
						else
						{
							List<FactionRelationSettings> factionRelations2 = generalSettings2.factionRelations;
							obj2 = ((factionRelations2 != null) ? new bool?(GenCollection.Any<FactionRelationSettings>(factionRelations2, (Predicate<FactionRelationSettings>)((FactionRelationSettings frs) => frs.factions?.Contains(((Def)f.def).defName) ?? false))) : null);
						}
					}
					bool? flag = obj2;
					return flag.GetValueOrDefault();
				}
				return false;
			});
		}

		public static void EnsureRequiredEnemiesPostfix(ref bool __result, Faction f)
		{
			__result = (__result || !FactionTickFactionRelationCheck(f));
		}

		public static void RecalculateLifeStageIndexPostfix(Pawn_AgeTracker __instance)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Invalid comparison between Unknown and I4
			Pawn value;
			if ((int)Current.get_ProgramState() == 2 && ((Thing)(value = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>())).def is ThingDef_AlienRace && value.get_Drawer().renderer.graphics.get_AllResolved())
			{
				value.get_Drawer().renderer.graphics.ResolveAllGraphics();
			}
		}

		public static void HasHeadPrefix(HediffSet __instance)
		{
			headPawnDef = (((Thing)__instance.pawn).def as ThingDef_AlienRace)?.alienRace.generalSettings.alienPartGenerator.headBodyPartDef;
		}

		public static void HasHeadPostfix(BodyPartRecord x, ref bool __result)
		{
			__result = ((headPawnDef != null) ? (x.def == headPawnDef) : __result);
		}

		public static void GenerateInitialHediffsPostfix(Pawn pawn)
		{
			Pawn_StoryTracker story = pawn.story;
			if (story != null)
			{
				(from bd in story.get_AllBackstories()?.Select((Backstory bs) => DefDatabase<BackstoryDef>.GetNamedSilentFail(bs.identifier))
					where bd != null
					select bd).SelectMany((BackstoryDef bd) => bd.forcedHediffs).Concat(bioReference?.forcedHediffs ?? new List<string>(0)).Select((Func<string, HediffDef>)DefDatabase<HediffDef>.GetNamedSilentFail)
					.ToList()
					.ForEach(delegate(HediffDef hd)
					{
						BodyPartRecord val = null;
						RecipeDef obj = DefDatabase<RecipeDef>.get_AllDefs().FirstOrDefault((RecipeDef rd) => rd.addsHediff == hd);
						if (obj != null)
						{
							GenCollection.TryRandomElement<BodyPartRecord>(obj.appliedOnFixedBodyParts.SelectMany((BodyPartDef bpd) => from bpr in pawn.health.hediffSet.GetNotMissingParts((BodyPartHeight)0, (BodyPartDepth)0, (BodyPartTagDef)null, (BodyPartRecord)null)
								where bpr.def == bpd && !GenCollection.Any<Hediff>(pawn.health.hediffSet.hediffs, (Predicate<Hediff>)((Hediff h) => h.def == hd && h.get_Part() == bpr))
								select bpr), ref val);
						}
						pawn.health.AddHediff(hd, val, (DamageInfo?)null, (DamageResult)null);
					});
			}
		}

		public static void GenerateStartingApparelForPostfix()
		{
			Traverse.Create(typeof(PawnApparelGenerator)).Field("allApparelPairs").GetValue<List<ThingStuffPair>>()
				.AddRange(apparelList);
		}

		public static void GenerateStartingApparelForPrefix(Pawn pawn)
		{
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			Traverse traverse = Traverse.Create(typeof(PawnApparelGenerator)).Field("allApparelPairs");
			apparelList = new HashSet<ThingStuffPair>();
			foreach (ThingStuffPair item in GenList.ListFullCopy<ThingStuffPair>(traverse.GetValue<List<ThingStuffPair>>()))
			{
				if (!RaceRestrictionSettings.CanWear(item.thing, ((Thing)pawn).def))
				{
					apparelList.Add(item);
				}
			}
			traverse.GetValue<List<ThingStuffPair>>().RemoveAll((ThingStuffPair tsp) => apparelList.Contains(tsp));
		}

		public static void TryGenerateWeaponForPostfix()
		{
			Traverse.Create(typeof(PawnWeaponGenerator)).Field("allWeaponPairs").GetValue<List<ThingStuffPair>>()
				.AddRange(weaponList);
		}

		public static void TryGenerateWeaponForPrefix(Pawn pawn)
		{
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			Traverse traverse = Traverse.Create(typeof(PawnWeaponGenerator)).Field("allWeaponPairs");
			weaponList = new HashSet<ThingStuffPair>();
			foreach (ThingStuffPair item in GenList.ListFullCopy<ThingStuffPair>(traverse.GetValue<List<ThingStuffPair>>()))
			{
				if (!RaceRestrictionSettings.CanEquip(item.thing, ((Thing)pawn).def))
				{
					weaponList.Add(item);
				}
			}
			traverse.GetValue<List<ThingStuffPair>>().RemoveAll((ThingStuffPair tsp) => weaponList.Contains(tsp));
		}

		public static void DamageInfosToApplyPostfix(Verb __instance, ref IEnumerable<DamageInfo> __result)
		{
			if (__instance.get_CasterIsPawn())
			{
				ThingDef def = ((Thing)__instance.get_CasterPawn()).def;
				ThingDef_AlienRace alienProps = def as ThingDef_AlienRace;
				if (alienProps != null && __instance.get_CasterPawn().get_CurJob().def == JobDefOf.SocialFight)
				{
					__result = __result.Select((Func<DamageInfo, DamageInfo>)((DamageInfo di) => new DamageInfo(((DamageInfo)(ref di)).get_Def(), Math.Min(((DamageInfo)(ref di)).get_Amount(), alienProps.alienRace.generalSettings.maxDamageForSocialfight), 0f, ((DamageInfo)(ref di)).get_Angle(), ((DamageInfo)(ref di)).get_Instigator(), ((DamageInfo)(ref di)).get_HitPart(), ((DamageInfo)(ref di)).get_Weapon(), ((DamageInfo)(ref di)).get_Category(), (Thing)null)));
				}
			}
		}

		public static void CanEverEat(ref bool __result, RaceProperties __instance, ThingDef t)
		{
			if (__instance.get_Humanlike())
			{
				ThingDef race = new List<ThingDef>(DefDatabase<ThingDef>.get_AllDefsListForReading()).Concat(new List<ThingDef_AlienRace>(DefDatabase<ThingDef_AlienRace>.get_AllDefsListForReading()).Cast<ThingDef>()).First((ThingDef td) => td.race == __instance);
				__result = (RaceRestrictionSettings.CanEat(t, race) & __result);
			}
		}

		public static IEnumerable<Rule> RulesForPawnPostfix(IEnumerable<Rule> __result, Pawn pawn, string pawnSymbol)
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected O, but got Unknown
			return __result.Add((Rule)(object)new Rule_String(pawnSymbol + "_alienRace", ((Def)((Thing)pawn).def).get_LabelCap()));
		}

		public static IEnumerable<CodeInstruction> GenerateTraitsTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			List<CodeInstruction> instructionList = instructions.ToList();
			MethodInfo defListInfo = AccessTools.Property(typeof(DefDatabase<TraitDef>), "AllDefsListForReading").GetGetMethod();
			MethodInfo validatorInfo = AccessTools.Method(patchType, "GenerateTraitsValidator");
			for (int i = 0; i < instructionList.Count; i++)
			{
				CodeInstruction instruction = instructionList[i];
				if (instruction.opcode == OpCodes.Call && instruction.operand == defListInfo)
				{
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					instruction.operand = validatorInfo;
					for (int j = 0; j < 4; j++)
					{
						instructionList.RemoveAt(i + 1);
					}
				}
				yield return instruction;
			}
		}

		public static TraitDef GenerateTraitsValidator(Pawn p)
		{
			return GenCollection.RandomElementByWeight<TraitDef>(from tr in DefDatabase<TraitDef>.get_AllDefs()
				where RaceRestrictionSettings.CanGetTrait(tr, ((Thing)p).def)
				select tr, (Func<TraitDef, float>)((TraitDef tr) => tr.GetGenderSpecificCommonality(p.gender)));
		}

		public static void AssigningCandidatesPostfix(ref IEnumerable<Pawn> __result, Building_Bed __instance)
		{
			__result = __result.Where((Pawn p) => RestUtility.CanUseBedEver(p, ((Thing)__instance).def));
		}

		public static void CanUseBedEverPostfix(ref bool __result, Pawn p, ThingDef bedDef)
		{
			if (__result)
			{
				ThingDef_AlienRace thingDef_AlienRace = ((Thing)p).def as ThingDef_AlienRace;
				__result = ((thingDef_AlienRace != null && (thingDef_AlienRace.alienRace.generalSettings.validBeds?.Contains(((Def)bedDef).defName) ?? false)) || !DefDatabase<ThingDef_AlienRace>.get_AllDefs().Any((ThingDef_AlienRace td) => td.alienRace.generalSettings.validBeds?.Contains(((Def)bedDef).defName) ?? false));
			}
		}

		public static IEnumerable<CodeInstruction> GetTraderCaravanRoleTranspiler(IEnumerable<CodeInstruction> instructions, ILGenerator il)
		{
			MethodInfo traderRoleInfo = AccessTools.Method(patchType, "GetTraderCaravanRoleInfix");
			foreach (CodeInstruction instruction in instructions)
			{
				if (instruction.opcode == OpCodes.Ldc_I4_3)
				{
					Label jumpToEnd = il.DefineLabel();
					yield return new CodeInstruction(OpCodes.Ldarg_0)
					{
						labels = GenList.ListFullCopy<Label>(instruction.labels)
					};
					instruction.labels.Clear();
					yield return new CodeInstruction(OpCodes.Call, traderRoleInfo);
					yield return new CodeInstruction(OpCodes.Brfalse_S, jumpToEnd);
					yield return new CodeInstruction(OpCodes.Ldc_I4_4);
					yield return new CodeInstruction(OpCodes.Ret);
					yield return new CodeInstruction(OpCodes.Nop)
					{
						labels = new List<Label>
						{
							jumpToEnd
						}
					};
				}
				yield return instruction;
			}
		}

		private static bool GetTraderCaravanRoleInfix(Pawn p)
		{
			if (((Thing)p).def is ThingDef_AlienRace)
			{
				return DefDatabase<RaceSettings>.get_AllDefs().Any((RaceSettings rs) => GenCollection.Any<PawnKindEntry>(rs.pawnKindSettings.alienslavekinds, (Predicate<PawnKindEntry>)((PawnKindEntry pke) => pke.kindDefs.Contains(((Def)p.kindDef).defName))));
			}
			return false;
		}

		public static bool GetGenderSpecificLabelPrefix(Pawn pawn, ref string __result, PawnRelationDef __instance)
		{
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0050: Invalid comparison between Unknown and I4
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				RelationRenamer relationRenamer = thingDef_AlienRace.alienRace.relationSettings.renamer?.FirstOrDefault((RelationRenamer rn) => GenText.EqualsIgnoreCase(rn.relation, ((Def)__instance).defName));
				if (relationRenamer != null)
				{
					__result = (((int)pawn.gender == 2) ? relationRenamer.femaleLabel : relationRenamer.label);
					if (Translator.CanTranslate(__result))
					{
						__result = Translator.Translate(__result);
					}
					return false;
				}
			}
			return true;
		}

		public static bool GeneratePawnRelationsPrefix(Pawn pawn, ref PawnGenerationRequest request)
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			PawnGenerationRequest localReq = request;
			if (!pawn.get_RaceProps().get_Humanlike() || pawn.get_RaceProps().hasGenders || !(((Thing)pawn).def is ThingDef_AlienRace))
			{
				return true;
			}
			List<KeyValuePair<Pawn, PawnRelationDef>> list = new List<KeyValuePair<Pawn, PawnRelationDef>>();
			List<PawnRelationDef> allDefsListForReading = DefDatabase<PawnRelationDef>.get_AllDefsListForReading();
			(from x in PawnsFinder.get_AllMapsWorldAndTemporary_AliveOrDead()
				where ((Thing)x).def == ((Thing)pawn).def
				select x).ToList().ForEach(delegate(Pawn current)
			{
				if (((Thing)current).get_Discarded())
				{
					Log.Warning("Warning during generating pawn relations for " + pawn + ": Pawn " + current + " is discarded, yet he was yielded by PawnUtility. Discarding a pawn means that he is no longer managed by anything.", false);
				}
				else
				{
					allDefsListForReading.ForEach(delegate(PawnRelationDef relationDef)
					{
						if (relationDef.generationChanceFactor > 0f)
						{
							list.Add(new KeyValuePair<Pawn, PawnRelationDef>(current, relationDef));
						}
					});
				}
			});
			KeyValuePair<Pawn, PawnRelationDef> keyValuePair = GenCollection.RandomElementByWeightWithDefault<KeyValuePair<Pawn, PawnRelationDef>>((IEnumerable<KeyValuePair<Pawn, PawnRelationDef>>)list, (Func<KeyValuePair<Pawn, PawnRelationDef>, float>)((KeyValuePair<Pawn, PawnRelationDef> x) => x.Value.familyByBloodRelation ? GenerationChanceGenderless(x.Value, pawn, x.Key, localReq) : 0f), 82f);
			Pawn key = keyValuePair.Key;
			if (key != null)
			{
				CreateRelationGenderless(keyValuePair.Value, pawn, key);
			}
			KeyValuePair<Pawn, PawnRelationDef> keyValuePair2 = GenCollection.RandomElementByWeightWithDefault<KeyValuePair<Pawn, PawnRelationDef>>((IEnumerable<KeyValuePair<Pawn, PawnRelationDef>>)list, (Func<KeyValuePair<Pawn, PawnRelationDef>, float>)((KeyValuePair<Pawn, PawnRelationDef> x) => (!x.Value.familyByBloodRelation) ? GenerationChanceGenderless(x.Value, pawn, x.Key, localReq) : 0f), 82f);
			key = keyValuePair2.Key;
			if (key != null)
			{
				CreateRelationGenderless(keyValuePair2.Value, pawn, key);
			}
			return false;
		}

		private static float GenerationChanceGenderless(PawnRelationDef relationDef, Pawn pawn, Pawn current, PawnGenerationRequest request)
		{
			//IL_0204: Unknown result type (might be due to invalid IL or missing references)
			float __result = relationDef.generationChanceFactor;
			float lifeExpectancy = pawn.get_RaceProps().lifeExpectancy;
			if (relationDef == PawnRelationDefOf.Child)
			{
				__result = ChanceOfBecomingGenderlessChildOf(current, pawn, current.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)((Pawn p) => p != pawn)));
				GenerationChanceChildPostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.ExLover)
			{
				__result = 0.5f;
				GenerationChanceExLoverPostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.ExSpouse)
			{
				__result = 0.5f;
				GenerationChanceExSpousePostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.Fiance)
			{
				__result = Mathf.Clamp(GenMath.LerpDouble(lifeExpectancy / 1.6f, lifeExpectancy, 1f, 0.01f, pawn.ageTracker.get_AgeBiologicalYearsFloat()), 0.01f, 1f) * Mathf.Clamp(GenMath.LerpDouble(lifeExpectancy / 1.6f, lifeExpectancy, 1f, 0.01f, current.ageTracker.get_AgeBiologicalYearsFloat()), 0.01f, 1f);
				GenerationChanceFiancePostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.Lover)
			{
				__result = 0.5f;
				GenerationChanceLoverPostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.Parent)
			{
				__result = ChanceOfBecomingGenderlessChildOf(current, pawn, current.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)((Pawn p) => p != pawn)));
				GenerationChanceParentPostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.Sibling)
			{
				__result = ChanceOfBecomingGenderlessChildOf(current, pawn, current.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)((Pawn p) => p != pawn)));
				__result *= 0.65f;
				GenerationChanceSiblingPostfix(ref __result, pawn, current);
			}
			else if (relationDef == PawnRelationDefOf.Spouse)
			{
				__result = 0.5f;
				GenerationChanceSpousePostfix(ref __result, pawn, current);
			}
			return __result * relationDef.get_Worker().BaseGenerationChanceFactor(pawn, current, request);
		}

		private static void CreateRelationGenderless(PawnRelationDef relationDef, Pawn pawn, Pawn other)
		{
			if (relationDef == PawnRelationDefOf.Child)
			{
				Pawn firstDirectRelationPawn = other.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)null);
				if (firstDirectRelationPawn != null)
				{
					pawn.relations.AddDirectRelation((LovePartnerRelationUtility.HasAnyLovePartner(firstDirectRelationPawn) || Rand.get_Value() > 0.8f) ? PawnRelationDefOf.ExLover : PawnRelationDefOf.Spouse, firstDirectRelationPawn);
				}
				other.relations.AddDirectRelation(PawnRelationDefOf.Parent, pawn);
			}
			if (relationDef == PawnRelationDefOf.ExLover)
			{
				if (!PawnRelationUtility.GetRelations(pawn, other).Contains(PawnRelationDefOf.ExLover))
				{
					pawn.relations.AddDirectRelation(PawnRelationDefOf.ExLover, other);
				}
				other.relations.get_Children().ToList().ForEach(delegate(Pawn p)
				{
					if (p.relations.get_DirectRelations().Count((DirectPawnRelation dpr) => dpr.def == PawnRelationDefOf.Parent) < 2 && (double)Rand.get_Value() < 0.35)
					{
						p.relations.AddDirectRelation(PawnRelationDefOf.Parent, pawn);
					}
				});
			}
			if (relationDef == PawnRelationDefOf.ExSpouse)
			{
				pawn.relations.AddDirectRelation(PawnRelationDefOf.ExSpouse, other);
				other.relations.get_Children().ToList().ForEach(delegate(Pawn p)
				{
					if (p.relations.get_DirectRelations().Count((DirectPawnRelation dpr) => dpr.def == PawnRelationDefOf.Parent) < 2 && Rand.get_Value() < 1f)
					{
						p.relations.AddDirectRelation(PawnRelationDefOf.Parent, pawn);
					}
				});
			}
			if (relationDef == PawnRelationDefOf.Fiance)
			{
				pawn.relations.AddDirectRelation(PawnRelationDefOf.Fiance, other);
				other.relations.get_Children().ToList().ForEach(delegate(Pawn p)
				{
					if (p.relations.get_DirectRelations().Count((DirectPawnRelation dpr) => dpr.def == PawnRelationDefOf.Parent) < 2 && (double)Rand.get_Value() < 0.7)
					{
						p.relations.AddDirectRelation(PawnRelationDefOf.Parent, pawn);
					}
				});
			}
			if (relationDef == PawnRelationDefOf.Lover)
			{
				pawn.relations.AddDirectRelation(PawnRelationDefOf.Lover, other);
				other.relations.get_Children().ToList().ForEach(delegate(Pawn p)
				{
					if (p.relations.get_DirectRelations().Count((DirectPawnRelation dpr) => dpr.def == PawnRelationDefOf.Parent) < 2 && Rand.get_Value() < 0.35f)
					{
						p.relations.AddDirectRelation(PawnRelationDefOf.Parent, pawn);
					}
				});
			}
			if (relationDef == PawnRelationDefOf.Parent)
			{
				Pawn firstDirectRelationPawn2 = other.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)null);
				if (firstDirectRelationPawn2 != null && pawn != firstDirectRelationPawn2 && !PawnRelationUtility.GetRelations(pawn, firstDirectRelationPawn2).Contains(PawnRelationDefOf.ExLover))
				{
					pawn.relations.AddDirectRelation((LovePartnerRelationUtility.HasAnyLovePartner(firstDirectRelationPawn2) || Rand.get_Value() > 0.8f) ? PawnRelationDefOf.ExLover : PawnRelationDefOf.Spouse, firstDirectRelationPawn2);
				}
				pawn.relations.AddDirectRelation(PawnRelationDefOf.Parent, other);
			}
			if (relationDef == PawnRelationDefOf.Sibling)
			{
				Pawn parent = other.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)null);
				List<DirectPawnRelation> list = (from dpr in other.relations.get_DirectRelations()
					where dpr.def == PawnRelationDefOf.Parent && dpr.otherPawn != parent
					select dpr).ToList();
				Pawn val = GenList.NullOrEmpty<DirectPawnRelation>((IList<DirectPawnRelation>)list) ? null : list.First().otherPawn;
				if (parent == null)
				{
					parent = PawnGenerator.GeneratePawn(other.kindDef, Find.get_FactionManager().FirstFactionOfDef(other.kindDef.defaultFactionType) ?? GenCollection.RandomElement<Faction>(Find.get_FactionManager().get_AllFactions()));
					if (!PawnRelationUtility.GetRelations(other, parent).Contains(PawnRelationDefOf.Parent))
					{
						other.relations.AddDirectRelation(PawnRelationDefOf.Parent, parent);
					}
				}
				if (val == null)
				{
					val = PawnGenerator.GeneratePawn(other.kindDef, Find.get_FactionManager().FirstFactionOfDef(other.kindDef.defaultFactionType) ?? GenCollection.RandomElement<Faction>(Find.get_FactionManager().get_AllFactions()));
					if (!PawnRelationUtility.GetRelations(other, val).Contains(PawnRelationDefOf.Parent))
					{
						other.relations.AddDirectRelation(PawnRelationDefOf.Parent, val);
					}
				}
				if (!PawnRelationUtility.GetRelations(parent, val).Any((PawnRelationDef prd) => prd == PawnRelationDefOf.ExLover || prd == PawnRelationDefOf.Lover))
				{
					parent.relations.AddDirectRelation((LovePartnerRelationUtility.HasAnyLovePartner(parent) || (double)Rand.get_Value() > 0.8) ? PawnRelationDefOf.ExLover : PawnRelationDefOf.Lover, val);
				}
				if (!PawnRelationUtility.GetRelations(pawn, parent).Contains(PawnRelationDefOf.Parent) && pawn != parent)
				{
					pawn.relations.AddDirectRelation(PawnRelationDefOf.Parent, parent);
				}
				if (!PawnRelationUtility.GetRelations(pawn, val).Contains(PawnRelationDefOf.Parent) && pawn != val)
				{
					pawn.relations.AddDirectRelation(PawnRelationDefOf.Parent, val);
				}
			}
			if (relationDef == PawnRelationDefOf.Spouse)
			{
				if (!PawnRelationUtility.GetRelations(pawn, other).Contains(PawnRelationDefOf.Spouse))
				{
					pawn.relations.AddDirectRelation(PawnRelationDefOf.Spouse, other);
				}
				other.relations.get_Children().ToList().ForEach(delegate(Pawn p)
				{
					if (pawn != p && p.relations.get_DirectRelations().Count((DirectPawnRelation dpr) => dpr.def == PawnRelationDefOf.Parent) < 2 && p.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, (Predicate<Pawn>)((Pawn x) => x == pawn)) == null && (double)Rand.get_Value() < 0.7)
					{
						p.relations.AddDirectRelation(PawnRelationDefOf.Parent, pawn);
					}
				});
			}
		}

		private static float ChanceOfBecomingGenderlessChildOf(Pawn child, Pawn parent1, Pawn parent2)
		{
			if (child == null || parent1 == null || (parent2 != null && child.relations.get_DirectRelations().Count((DirectPawnRelation dpr) => dpr.def == PawnRelationDefOf.Parent) <= 1))
			{
				return 0f;
			}
			if (parent2 != null && !LovePartnerRelationUtility.LovePartnerRelationExists(parent1, parent2) && !LovePartnerRelationUtility.ExLovePartnerRelationExists(parent1, parent2))
			{
				return 0f;
			}
			float num = 1f;
			float num2 = 1f;
			Traverse traverse = Traverse.Create(typeof(ChildRelationUtility));
			float value = traverse.Method("GetParentAgeFactor", parent1, child, parent1.get_RaceProps().lifeExpectancy / 5f, parent1.get_RaceProps().lifeExpectancy / 2.5f, parent1.get_RaceProps().lifeExpectancy / 1.6f).GetValue<float>();
			if (Math.Abs(value) < 0.001f)
			{
				return 0f;
			}
			if (parent2 != null)
			{
				num = traverse.Method("GetParentAgeFactor", parent2, child, parent1.get_RaceProps().lifeExpectancy / 5f, parent1.get_RaceProps().lifeExpectancy / 2.5f, parent1.get_RaceProps().lifeExpectancy / 1.6f).GetValue<float>();
				if (Math.Abs(num) < 0.001f)
				{
					return 0f;
				}
				num2 = 1f;
			}
			float num3 = 1f;
			Pawn val = (parent2 != null) ? parent2.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Spouse, (Predicate<Pawn>)null) : null;
			if (val != null && val != parent2)
			{
				num3 *= 0.15f;
			}
			if (parent2 == null)
			{
				return value * num * num2 * num3;
			}
			Pawn firstDirectRelationPawn = parent2.relations.GetFirstDirectRelationPawn(PawnRelationDefOf.Spouse, (Predicate<Pawn>)null);
			if (firstDirectRelationPawn != null && firstDirectRelationPawn != parent2)
			{
				num3 *= 0.15f;
			}
			return value * num * num2 * num3;
		}

		public static bool GainTraitPrefix(Trait trait, TraitSet __instance)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)Traverse.Create(__instance).Field("pawn").GetValue<Pawn>()).def as ThingDef_AlienRace;
			if (thingDef_AlienRace == null)
			{
				return true;
			}
			if (thingDef_AlienRace.alienRace.generalSettings.disallowedTraits?.Contains(((Def)trait.def).defName) ?? false)
			{
				return false;
			}
			AlienTraitEntry alienTraitEntry = thingDef_AlienRace.alienRace.generalSettings.forcedRaceTraitEntries?.FirstOrDefault((AlienTraitEntry at) => GenText.EqualsIgnoreCase(at.defName, ((Def)trait.def).defName));
			if (alienTraitEntry == null)
			{
				return true;
			}
			return (float)Rand.Range(0, 100) < alienTraitEntry.chance;
		}

		public static void TryMakeInitialRelationsWithPostfix(Faction __instance, Faction other)
		{
			(other.def.basicMemberKind?.race as ThingDef_AlienRace)?.alienRace.generalSettings.factionRelations?.ForEach(delegate(FactionRelationSettings frs)
			{
				//IL_003b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0055: Unknown result type (might be due to invalid IL or missing references)
				//IL_0056: Unknown result type (might be due to invalid IL or missing references)
				//IL_0074: Unknown result type (might be due to invalid IL or missing references)
				//IL_0075: Unknown result type (might be due to invalid IL or missing references)
				if (frs.factions.Contains(((Def)__instance.def).defName))
				{
					int randomInRange2 = ((IntRange)(ref frs.goodwill)).get_RandomInRange();
					FactionRelationKind kind2 = (FactionRelationKind)((randomInRange2 > 75) ? 2 : ((randomInRange2 > -10) ? 1 : 0));
					FactionRelation obj3 = other.RelationWith(__instance, false);
					obj3.goodwill = randomInRange2;
					obj3.kind = kind2;
					FactionRelation obj4 = __instance.RelationWith(other, false);
					obj4.goodwill = randomInRange2;
					obj4.kind = kind2;
				}
			});
			(__instance.def.basicMemberKind?.race as ThingDef_AlienRace)?.alienRace.generalSettings.factionRelations?.ForEach(delegate(FactionRelationSettings frs)
			{
				//IL_003b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0055: Unknown result type (might be due to invalid IL or missing references)
				//IL_0056: Unknown result type (might be due to invalid IL or missing references)
				//IL_0074: Unknown result type (might be due to invalid IL or missing references)
				//IL_0075: Unknown result type (might be due to invalid IL or missing references)
				if (frs.factions.Contains(((Def)other.def).defName))
				{
					int randomInRange = ((IntRange)(ref frs.goodwill)).get_RandomInRange();
					FactionRelationKind kind = (FactionRelationKind)((randomInRange > 75) ? 2 : ((randomInRange > -10) ? 1 : 0));
					FactionRelation obj = other.RelationWith(__instance, false);
					obj.goodwill = randomInRange;
					obj.kind = kind;
					FactionRelation obj2 = __instance.RelationWith(other, false);
					obj2.goodwill = randomInRange;
					obj2.kind = kind;
				}
			});
		}

		public static bool TryCreateThoughtPrefix(ref ThoughtDef def, SituationalThoughtHandler __instance)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)__instance.pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				def = thingDef_AlienRace.alienRace.thoughtSettings.ReplaceIfApplicable(def);
			}
			return !Traverse.Create(__instance).Field("tmpCachedThoughts").GetValue<HashSet<ThoughtDef>>()
				.Contains(def);
		}

		public static void CanBingeNowPostfix(Pawn pawn, ChemicalDef chemical, ref bool __result)
		{
			if (__result)
			{
				ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
				if (thingDef_AlienRace != null)
				{
					bool result = true;
					thingDef_AlienRace.alienRace.generalSettings.chemicalSettings?.ForEach(delegate(ChemicalSettings cs)
					{
						string chemical2 = cs.chemical;
						if (chemical2 != null && GenText.EqualsIgnoreCase(chemical2, ((Def)chemical).defName) && !cs.ingestible)
						{
							result = false;
						}
					});
					__result = result;
				}
			}
		}

		public static void PostIngestedPostfix(Pawn ingester, CompDrug __instance)
		{
			(((Thing)ingester).def as ThingDef_AlienRace)?.alienRace.generalSettings.chemicalSettings?.ForEach(delegate(ChemicalSettings cs)
			{
				string chemical = cs.chemical;
				if (chemical != null && GenText.EqualsIgnoreCase(chemical, ((Def)(__instance.get_Props()?.chemical?)).defName))
				{
					cs.reactions?.ForEach(delegate(IngestionOutcomeDoer iod)
					{
						iod.DoIngestionOutcome(ingester, (Thing)(object)((ThingComp)__instance).parent);
					});
				}
			});
		}

		public static void DrugValidatorPostfix(ref bool __result, Pawn pawn, Thing drug)
		{
			object chemical;
			if (drug == null)
			{
				chemical = null;
			}
			else
			{
				CompDrug obj = ThingCompUtility.TryGetComp<CompDrug>(drug);
				chemical = ((obj == null) ? null : obj.get_Props()?.chemical);
			}
			CanBingeNowPostfix(pawn, (ChemicalDef)chemical, ref __result);
		}

		public static void CompatibilityWithPostfix(Pawn_RelationsTracker __instance, Pawn otherPawn, ref float __result)
		{
			Pawn value = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
			if (value.get_RaceProps().get_Humanlike() != otherPawn.get_RaceProps().get_Humanlike() || value == otherPawn)
			{
				__result = 0f;
				return;
			}
			float num = Mathf.Abs(value.ageTracker.get_AgeBiologicalYearsFloat() - otherPawn.ageTracker.get_AgeBiologicalYearsFloat());
			float num2 = GenMath.LerpDouble(0f, 20f, 0.45f, -0.45f, num);
			num2 = Mathf.Clamp(num2, -0.45f, 0.45f);
			float num3 = __instance.ConstantPerPawnsPairCompatibilityOffset(((Thing)otherPawn).thingIDNumber);
			__result = num2 + num3;
		}

		public static IEnumerable<CodeInstruction> SecondaryLovinChanceFactorTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			FieldInfo defField = AccessTools.Field(typeof(Pawn), "def");
			MethodInfo racePropsProperty = AccessTools.Property(typeof(Pawn), "RaceProps").GetGetMethod();
			MethodInfo humanlikeProperty = AccessTools.Property(typeof(RaceProperties), "Humanlike").GetGetMethod();
			int counter = 0;
			foreach (CodeInstruction instruction in instructions)
			{
				counter++;
				if (counter < 10 && instruction.opcode == OpCodes.Ldfld && instruction.operand == defField)
				{
					yield return new CodeInstruction(OpCodes.Callvirt, racePropsProperty);
					instruction.opcode = OpCodes.Callvirt;
					instruction.operand = humanlikeProperty;
				}
				yield return instruction;
			}
		}

		public static void GenericHasJobOnThingPostfix(WorkGiver __instance, Pawn pawn, ref bool __result)
		{
			if (__result)
			{
				ThingDef_AlienRace obj = ((Thing)pawn).def as ThingDef_AlienRace;
				bool? obj2;
				if (obj == null)
				{
					obj2 = null;
				}
				else
				{
					List<string> workGiverList = obj.alienRace.raceRestriction.workGiverList;
					obj2 = ((workGiverList != null) ? new bool?(GenCollection.Any<string>(workGiverList, (Predicate<string>)((string wgd) => DefDatabase<WorkGiverDef>.GetNamedSilentFail(wgd)?.giverClass == ((object)__instance).GetType()))) : null);
				}
				bool? flag = obj2;
				__result = (flag.GetValueOrDefault() || !GenCollection.Any<ThingDef_AlienRace>(DefDatabase<ThingDef_AlienRace>.get_AllDefsListForReading(), (Predicate<ThingDef_AlienRace>)delegate(ThingDef_AlienRace d)
				{
					if (((Thing)pawn).def != d)
					{
						List<string> workGiverList2 = d.alienRace.raceRestriction.workGiverList;
						if (workGiverList2 == null)
						{
							return false;
						}
						return GenCollection.Any<string>(workGiverList2, (Predicate<string>)((string wgd) => DefDatabase<WorkGiverDef>.GetNamedSilentFail(wgd)?.giverClass == ((object)__instance).GetType()));
					}
					return false;
				}));
			}
		}

		public static void GenericJobOnThingPostfix(WorkGiver __instance, Pawn pawn, ref Job __result)
		{
			if (__result != null)
			{
				ThingDef_AlienRace obj = ((Thing)pawn).def as ThingDef_AlienRace;
				bool? obj2;
				if (obj == null)
				{
					obj2 = null;
				}
				else
				{
					List<string> workGiverList = obj.alienRace.raceRestriction.workGiverList;
					obj2 = ((workGiverList != null) ? new bool?(GenCollection.Any<string>(workGiverList, (Predicate<string>)((string wgd) => DefDatabase<WorkGiverDef>.GetNamedSilentFail(wgd)?.giverClass == ((object)__instance).GetType()))) : null);
				}
				bool? flag = obj2;
				if (!flag.GetValueOrDefault() && GenCollection.Any<ThingDef_AlienRace>(DefDatabase<ThingDef_AlienRace>.get_AllDefsListForReading(), (Predicate<ThingDef_AlienRace>)delegate(ThingDef_AlienRace d)
				{
					if (((Thing)pawn).def != d)
					{
						List<string> workGiverList2 = d.alienRace.raceRestriction.workGiverList;
						if (workGiverList2 == null)
						{
							return false;
						}
						return GenCollection.Any<string>(workGiverList2, (Predicate<string>)((string wgd) => DefDatabase<WorkGiverDef>.GetNamedSilentFail(wgd)?.giverClass == ((object)__instance).GetType()));
					}
					return false;
				}))
				{
					__result = null;
				}
			}
		}

		public static void SetFactionDirectPostfix(Thing __instance, Faction newFaction)
		{
			ThingDef_AlienRace thingDef_AlienRace = __instance.def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null && newFaction == Faction.get_OfPlayerSilentFail())
			{
				thingDef_AlienRace.alienRace.raceRestriction.conceptList?.ForEach(delegate(string cdd)
				{
					ConceptDef namedSilentFail = DefDatabase<ConceptDef>.GetNamedSilentFail(cdd);
					if (cdd != null)
					{
						Find.get_Tutor().learningReadout.TryActivateConcept(namedSilentFail);
						PlayerKnowledgeDatabase.SetKnowledge(namedSilentFail, 0f);
					}
				});
			}
		}

		public static void SetFactionPostfix(Pawn __instance, Faction newFaction)
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Invalid comparison between Unknown and I4
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)__instance).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null && newFaction == Faction.get_OfPlayerSilentFail() && (int)Current.get_ProgramState() == 2)
			{
				thingDef_AlienRace.alienRace.raceRestriction.conceptList?.ForEach(delegate(string cdd)
				{
					ConceptDef namedSilentFail = DefDatabase<ConceptDef>.GetNamedSilentFail(cdd);
					if (cdd != null)
					{
						Find.get_Tutor().learningReadout.TryActivateConcept(namedSilentFail);
						PlayerKnowledgeDatabase.SetKnowledge(namedSilentFail, 0f);
					}
				});
			}
		}

		public static void ApparelScoreGainPostFix(Pawn pawn, Apparel ap, ref float __result)
		{
			if (__result >= 0f && !RaceRestrictionSettings.CanWear(((Thing)ap).def, ((Thing)pawn).def))
			{
				__result = -50f;
			}
		}

		public static void PrepForMapGenPrefix(GameInitData __instance)
		{
			(from sp in Find.get_Scenario().get_AllParts().OfType<ScenPart_StartingHumanlikes>()
				select sp.GetPawns()).ToList().ForEach(delegate(IEnumerable<Pawn> sp)
			{
				IEnumerable<Pawn> enumerable = (sp as Pawn[]) ?? sp.ToArray();
				__instance.startingAndOptionalPawns.InsertRange(__instance.startingPawnCount, enumerable);
				GameInitData obj = __instance;
				obj.startingPawnCount += enumerable.Count();
			});
		}

		public static bool TryGainMemoryPrefix(ref Thought_Memory newThought, MemoryThoughtHandler __instance)
		{
			//IL_0040: Unknown result type (might be due to invalid IL or missing references)
			//IL_0046: Expected O, but got Unknown
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)__instance.pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace == null)
			{
				return true;
			}
			ThoughtDef val = thingDef_AlienRace.alienRace.thoughtSettings.ReplaceIfApplicable(((Thought)newThought).def);
			if (val == ((Thought)newThought).def)
			{
				return true;
			}
			Thought_Memory val2 = newThought = (Thought_Memory)(object)(Thought_Memory)ThoughtMaker.MakeThought(val);
			return true;
		}

		public static void ExtraRequirementsGrowerSowPostfix(Pawn pawn, IPlantToGrowSettable settable, ref bool __result)
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			if (__result)
			{
				object obj = (object)(settable as Zone_Growing);
				ThingDef plant = WorkGiver_Grower.CalculateWantedPlantDef((obj != null) ? ((Zone)obj).get_Cells()[0] : ((Thing)settable).get_Position(), ((Thing)pawn).get_Map());
				__result = RaceRestrictionSettings.CanPlant(plant, ((Thing)pawn).def);
			}
		}

		public static void HasJobOnCellHarvestPostfix(Pawn pawn, IntVec3 c, ref bool __result)
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			if (__result)
			{
				ThingDef def = ((Thing)GridsUtility.GetPlant(c, ((Thing)pawn).get_Map())).def;
				__result = RaceRestrictionSettings.CanPlant(def, ((Thing)pawn).def);
			}
		}

		public static void PawnAllowedToStartAnewPostfix(Pawn p, Bill __instance, ref bool __result)
		{
			RecipeDef recipe = __instance.recipe;
			if (__result)
			{
				__result = RaceRestrictionSettings.CanDoRecipe(recipe, ((Thing)p).def);
			}
		}

		public static void DesignatorAllowedPostfix(Designator d, ref bool __result)
		{
			if (!__result)
			{
				return;
			}
			Designator_Build build = d as Designator_Build;
			if (build != null)
			{
				if ((Find.get_TickManager().get_TicksAbs() > colonistRacesTick + 5000 || Find.get_TickManager().get_TicksAbs() < colonistRacesTick) && (colonistRaces = new HashSet<ThingDef>(from p in PawnsFinder.get_AllMaps_FreeColonistsSpawned()
					select ((Thing)p).def)).Count > 0)
				{
					colonistRacesTick = Find.get_TickManager().get_TicksAbs();
				}
				__result = colonistRaces.Any((ThingDef ar) => RaceRestrictionSettings.CanBuild(((Designator_Place)build).get_PlacingDef(), ar));
			}
		}

		public static void CanConstructPostfix(Thing t, Pawn p, ref bool __result)
		{
			if (__result)
			{
				__result = RaceRestrictionSettings.CanBuild((BuildableDef)(((object)t.def.entityDefToBuild) ?? ((object)t.def)), ((Thing)p).def);
			}
		}

		public static IEnumerable<CodeInstruction> ResearchScreenTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			MethodInfo defListInfo = AccessTools.Method(typeof(DefDatabase<ResearchProjectDef>), "AllDefsListForReading");
			foreach (CodeInstruction instruction in instructions)
			{
				if (instruction.opcode == OpCodes.Call && instruction.operand == defListInfo)
				{
					yield return instruction;
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "ResearchFixed"));
				}
				else
				{
					yield return instruction;
				}
			}
		}

		private static List<ResearchProjectDef> ResearchFixed(List<ResearchProjectDef> researchList)
		{
			return researchList.Where((ResearchProjectDef prj) => !GenCollection.Any<ThingDef_AlienRace>(DefDatabase<ThingDef_AlienRace>.get_AllDefsListForReading(), (Predicate<ThingDef_AlienRace>)delegate(ThingDef_AlienRace ar)
			{
				if (!colonistRaces.Contains((ThingDef)(object)ar))
				{
					RaceRestrictionSettings raceRestriction = ar.alienRace.raceRestriction;
					bool? obj;
					if (raceRestriction == null)
					{
						obj = null;
					}
					else
					{
						List<ResearchProjectRestrictions> researchList2 = raceRestriction.researchList;
						obj = ((researchList2 != null) ? new bool?(GenCollection.Any<ResearchProjectRestrictions>(researchList2, (Predicate<ResearchProjectRestrictions>)((ResearchProjectRestrictions rpr) => rpr.projects.Contains(((Def)prj).defName)))) : null);
					}
					bool? flag = obj;
					return flag.GetValueOrDefault();
				}
				return false;
			})).ToList();
		}

		public static void ShouldSkipResearchPostfix(Pawn pawn, ref bool __result)
		{
			if (__result)
			{
				return;
			}
			ResearchProjectDef project = Find.get_ResearchManager().currentProj;
			ResearchProjectRestrictions researchProjectRestrictions = (((Thing)pawn).def as ThingDef_AlienRace)?.alienRace.raceRestriction.researchList?.FirstOrDefault((ResearchProjectRestrictions rpr) => rpr.projects.Contains(((Def)project).defName));
			if (researchProjectRestrictions != null)
			{
				IEnumerable<string> apparel = from twc in pawn.apparel.get_WornApparel()
					select ((Def)((Thing)twc).def).defName;
				List<string> list = researchProjectRestrictions.apparelList;
				if (list != null && !list.TrueForAll((string ap) => apparel.Contains(ap)))
				{
					__result = true;
				}
			}
			else
			{
				__result = GenCollection.Any<ThingDef_AlienRace>(DefDatabase<ThingDef_AlienRace>.get_AllDefsListForReading(), (Predicate<ThingDef_AlienRace>)delegate(ThingDef_AlienRace d)
				{
					if (((Thing)pawn).def != d)
					{
						List<ResearchProjectRestrictions> researchList = d.alienRace.raceRestriction.researchList;
						if (researchList == null)
						{
							return false;
						}
						return GenCollection.Any<ResearchProjectRestrictions>(researchList, (Predicate<ResearchProjectRestrictions>)((ResearchProjectRestrictions rpr) => rpr.projects.Contains(((Def)project).defName)));
					}
					return false;
				});
			}
		}

		public static void ThoughtsFromIngestingPostfix(Pawn ingester, Thing foodSource, ref List<ThoughtDef> __result)
		{
			if (ingester.story.traits.HasTrait(AlienDefOf.Xenophobia) && ingester.story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) == 1)
			{
				if (__result.Contains(ThoughtDefOf.AteHumanlikeMeatDirect) && foodSource.def.ingestible.sourceDef != ((Thing)ingester).def)
				{
					__result.Remove(ThoughtDefOf.AteHumanlikeMeatDirect);
				}
				else if (__result.Contains(ThoughtDefOf.AteHumanlikeMeatAsIngredient))
				{
					CompIngredients obj = ThingCompUtility.TryGetComp<CompIngredients>(foodSource);
					if (obj != null && GenCollection.Any<ThingDef>(obj.ingredients, (Predicate<ThingDef>)((ThingDef td) => FoodUtility.IsHumanlikeMeat(td) && td.ingestible.sourceDef != ((Thing)ingester).def)))
					{
						__result.Remove(ThoughtDefOf.AteHumanlikeMeatAsIngredient);
					}
				}
			}
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)ingester).def as ThingDef_AlienRace;
			if (thingDef_AlienRace == null)
			{
				return;
			}
			bool cannibal = ingester.story.traits.HasTrait(TraitDefOf.Cannibal);
			for (int i = 0; i < __result.Count; i++)
			{
				ThoughtDef def = __result[i];
				ThoughtSettings thoughtSettings = thingDef_AlienRace.alienRace.thoughtSettings;
				def = thoughtSettings.ReplaceIfApplicable(def);
				if (def == ThoughtDefOf.AteHumanlikeMeatDirect || def == ThoughtDefOf.AteHumanlikeMeatDirectCannibal)
				{
					def = thoughtSettings.GetAteThought(foodSource.def.ingestible.sourceDef, cannibal, ingredient: false);
				}
				if (def == ThoughtDefOf.AteHumanlikeMeatAsIngredient || def == ThoughtDefOf.AteHumanlikeMeatAsIngredientCannibal)
				{
					ThingDef val = ThingCompUtility.TryGetComp<CompIngredients>(foodSource)?.ingredients.FirstOrDefault(delegate(ThingDef td)
					{
						IngestibleProperties ingestible = td.ingestible;
						bool? obj2;
						if (ingestible == null)
						{
							obj2 = null;
						}
						else
						{
							ThingDef sourceDef = ingestible.sourceDef;
							if (sourceDef == null)
							{
								obj2 = null;
							}
							else
							{
								RaceProperties race = sourceDef.race;
								obj2 = ((race != null) ? new bool?(race.get_Humanlike()) : null);
							}
						}
						bool? flag = obj2;
						return flag.GetValueOrDefault();
					});
					if (val != null)
					{
						def = thoughtSettings.GetAteThought(val, cannibal, ingredient: true);
					}
				}
				__result[i] = def;
			}
		}

		public static void GenerationChanceSpousePostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierSpouse;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierSpouse;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSpouse ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSpouse ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSpouse ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSpouse ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceSiblingPostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierSibling;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierSibling;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSibling ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSibling ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSibling ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierSibling ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceParentPostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierParent;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierParent;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierParent ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierParent ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierParent ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierParent ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceLoverPostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierLover;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierLover;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierLover ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierLover ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierLover ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierLover ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceFiancePostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierFiance;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierFiance;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierFiance ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierFiance ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierFiance ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierFiance ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceExSpousePostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierExSpouse;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierExSpouse;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExSpouse ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExSpouse ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExSpouse ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExSpouse ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceExLoverPostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierExLover;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierExLover;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExLover ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExLover ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExLover ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierExLover ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void GenerationChanceChildPostfix(ref float __result, Pawn generated, Pawn other)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)generated).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result *= thingDef_AlienRace.alienRace.relationSettings.relationChanceModifierChild;
			}
			ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)other).def as ThingDef_AlienRace;
			if (thingDef_AlienRace2 != null)
			{
				__result *= thingDef_AlienRace2.alienRace.relationSettings.relationChanceModifierChild;
			}
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierChild ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(generated.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierChild ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)0)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierChild ?? 1f);
			__result *= (DefDatabase<BackstoryDef>.GetNamedSilentFail(other.story.GetBackstory((BackstorySlot)1)?.identifier ?? "nothingHere")?.relationSettings.relationChanceModifierChild ?? 1f);
			if (generated == other)
			{
				__result = 0f;
			}
		}

		public static void BirthdayBiologicalPrefix(Pawn_AgeTracker __instance)
		{
			//IL_010b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0115: Expected O, but got Unknown
			Pawn value = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)value).def as ThingDef_AlienRace;
			if (thingDef_AlienRace == null || !((Thing)value).def.race.lifeStageAges.Skip(1).Any() || value.ageTracker.get_CurLifeStageIndex() == 0)
			{
				return;
			}
			LifeStageAge curLifeStageRace = value.ageTracker.get_CurLifeStageRace();
			LifeStageAge val = ((Thing)value).def.race.lifeStageAges[value.ageTracker.get_CurLifeStageIndex() - 1];
			LifeStageAgeAlien lifeStageAgeAlien = curLifeStageRace as LifeStageAgeAlien;
			if (lifeStageAgeAlien == null || lifeStageAgeAlien.body == null || ((val as LifeStageAgeAlien)?.body ?? value.get_RaceProps().body) == lifeStageAgeAlien.body)
			{
				LifeStageAgeAlien lifeStageAgeAlien2 = val as LifeStageAgeAlien;
				if (lifeStageAgeAlien2 == null || lifeStageAgeAlien2.body == null || ((curLifeStageRace as LifeStageAgeAlien)?.body ?? value.get_RaceProps().body) == lifeStageAgeAlien2.body)
				{
					return;
				}
			}
			value.health.hediffSet = (HediffSet)(object)new HediffSet(value);
			string head = thingDef_AlienRace.alienRace.graphicPaths.GetCurrentGraphicPath(value.ageTracker.get_CurLifeStageRace().def).head;
			Traverse.Create(value.story).Field("headGraphicPath").SetValue(thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.RandomAlienHead(head, value));
		}

		public static bool ButcherProductsPrefix(Pawn butcher, float efficiency, ref IEnumerable<Thing> __result, Corpse __instance)
		{
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			Pawn corpse = __instance.get_InnerPawn();
			IEnumerable<Thing> enumerable = ((Thing)corpse).ButcherProducts(butcher, efficiency);
			if (corpse.get_RaceProps().get_BloodDef() != null)
			{
				FilthMaker.MakeFilth(((Thing)butcher).get_Position(), ((Thing)butcher).get_Map(), corpse.get_RaceProps().get_BloodDef(), GenText.LabelIndefinite(corpse), 1);
			}
			if (!corpse.get_RaceProps().get_Humanlike())
			{
				__result = enumerable;
				return false;
			}
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)butcher).def as ThingDef_AlienRace;
			ThoughtDef thought = (thingDef_AlienRace == null) ? ThoughtDefOf.ButcheredHumanlikeCorpse : DefDatabase<ThoughtDef>.GetNamedSilentFail(thingDef_AlienRace.alienRace.thoughtSettings.butcherThoughtSpecific?.FirstOrDefault((ButcherThought bt) => bt.raceList?.Contains(((Def)((Thing)corpse).def).defName) ?? false)?.thought ?? thingDef_AlienRace.alienRace.thoughtSettings.butcherThoughtGeneral.thought);
			Pawn_NeedsTracker needs = butcher.needs;
			if (needs != null)
			{
				Need_Mood mood = needs.mood;
				if (mood != null)
				{
					ThoughtHandler thoughts = mood.thoughts;
					if (thoughts != null)
					{
						MemoryThoughtHandler memories = thoughts.memories;
						if (memories != null)
						{
							memories.TryGainMemory(thought ?? ThoughtDefOf.ButcheredHumanlikeCorpse, (Pawn)null);
						}
					}
				}
			}
			((Thing)butcher).get_Map().mapPawns.SpawnedPawnsInFaction(((Thing)butcher).get_Faction()).ForEach(delegate(Pawn p)
			{
				if (p != butcher && p.needs?.mood?.thoughts != null)
				{
					ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)p).def as ThingDef_AlienRace;
					thought = ((thingDef_AlienRace2 == null) ? ThoughtDefOf.KnowButcheredHumanlikeCorpse : DefDatabase<ThoughtDef>.GetNamedSilentFail(thingDef_AlienRace2.alienRace.thoughtSettings.butcherThoughtSpecific?.FirstOrDefault((ButcherThought bt) => bt.raceList?.Contains(((Def)((Thing)corpse).def).defName) ?? false)?.knowThought ?? thingDef_AlienRace2.alienRace.thoughtSettings.butcherThoughtGeneral.knowThought));
					p.needs.mood.thoughts.memories.TryGainMemory(thought ?? ThoughtDefOf.KnowButcheredHumanlikeCorpse, (Pawn)null);
				}
			});
			TaleRecorder.RecordTale(TaleDefOf.ButcheredHumanlikeCorpse, new object[1]
			{
				butcher
			});
			__result = enumerable;
			return false;
		}

		public static void AddHumanlikeOrdersPostfix(ref List<FloatMenuOption> opts, Pawn pawn, Vector3 clickPos)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_012c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0136: Expected O, but got Unknown
			//IL_0163: Unknown result type (might be due to invalid IL or missing references)
			//IL_0193: Unknown result type (might be due to invalid IL or missing references)
			//IL_019d: Expected O, but got Unknown
			//IL_022a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0259: Unknown result type (might be due to invalid IL or missing references)
			//IL_0263: Expected O, but got Unknown
			//IL_0299: Unknown result type (might be due to invalid IL or missing references)
			//IL_032a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0336: Unknown result type (might be due to invalid IL or missing references)
			//IL_0365: Unknown result type (might be due to invalid IL or missing references)
			//IL_036f: Expected O, but got Unknown
			IntVec3 val = IntVec3.FromVector3(clickPos);
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			Thing drugs = GridsUtility.GetThingList(val, ((Thing)pawn).get_Map()).FirstOrDefault((Thing t) => ((t != null) ? ThingCompUtility.TryGetComp<CompDrug>(t) : null) != null);
			if (drugs != null)
			{
				bool? obj;
				if (thingDef_AlienRace == null)
				{
					obj = null;
				}
				else
				{
					List<ChemicalSettings> chemicalSettings = thingDef_AlienRace.alienRace.generalSettings.chemicalSettings;
					obj = ((chemicalSettings != null) ? new bool?(GenCollection.Any<ChemicalSettings>(chemicalSettings, (Predicate<ChemicalSettings>)delegate(ChemicalSettings cs)
					{
						string chemical = cs.chemical;
						CompDrug obj2 = ThingCompUtility.TryGetComp<CompDrug>(drugs);
						return GenText.EqualsIgnoreCase(chemical, (obj2 == null) ? null : ((Def)(obj2.get_Props().chemical?)).defName) && !cs.ingestible;
					})) : null);
				}
				bool? flag = obj;
				if (flag.GetValueOrDefault())
				{
					foreach (FloatMenuOption item in opts.Where((FloatMenuOption fmo) => !fmo.get_Disabled() && fmo.get_Label().Contains(string.Format(drugs.def.ingestible.ingestCommandString, ((Entity)drugs).get_LabelShort()))).ToList())
					{
						int index = opts.IndexOf(item);
						opts.Remove(item);
						opts.Insert(index, (FloatMenuOption)(object)new FloatMenuOption(TranslatorFormattedStringExtensions.Translate("CannotEquip", NamedArgument.op_Implicit(((Entity)drugs).get_LabelShort())) + " " + ((Def)((Thing)pawn).def).get_LabelCap() + " can't consume this)", (Action)null, (MenuOptionPriority)4, (Action)null, (Thing)null, 0f, (Func<Rect, bool>)null, (WorldObject)null));
					}
				}
			}
			if (pawn.equipment != null)
			{
				ThingWithComps equipment = (ThingWithComps)(object)(ThingWithComps)GridsUtility.GetThingList(val, ((Thing)pawn).get_Map()).FirstOrDefault((Thing t) => ThingCompUtility.TryGetComp<CompEquippable>(t) != null && t.def.get_IsWeapon());
				if (equipment != null)
				{
					List<FloatMenuOption> list = opts.Where((FloatMenuOption fmo) => !fmo.get_Disabled() && fmo.get_Label().Contains(TranslatorFormattedStringExtensions.Translate("Equip", NamedArgument.op_Implicit(((Entity)equipment).get_LabelShort())))).ToList();
					if (!GenList.NullOrEmpty<FloatMenuOption>((IList<FloatMenuOption>)list) && !RaceRestrictionSettings.CanEquip(((Thing)equipment).def, ((Thing)pawn).def))
					{
						foreach (FloatMenuOption item2 in list)
						{
							int index2 = opts.IndexOf(item2);
							opts.Remove(item2);
							opts.Insert(index2, (FloatMenuOption)(object)new FloatMenuOption(TranslatorFormattedStringExtensions.Translate("CannotEquip", NamedArgument.op_Implicit(((Entity)equipment).get_LabelShort())) + " (" + ((Def)((Thing)pawn).def).get_LabelCap() + " can't equip this)", (Action)null, (MenuOptionPriority)4, (Action)null, (Thing)null, 0f, (Func<Rect, bool>)null, (WorldObject)null));
						}
					}
				}
			}
			if (pawn.apparel == null)
			{
				return;
			}
			Apparel apparel = ((Thing)pawn).get_Map().thingGrid.ThingAt<Apparel>(val);
			if (apparel != null)
			{
				List<FloatMenuOption> list2 = opts.Where((FloatMenuOption fmo) => !fmo.get_Disabled() && fmo.get_Label().Contains(TranslatorFormattedStringExtensions.Translate("ForceWear", NamedArgument.op_Implicit(((Entity)apparel).get_LabelShort()), NamedArgument.op_Implicit((Thing)(object)apparel)))).ToList();
				if (!GenList.NullOrEmpty<FloatMenuOption>((IList<FloatMenuOption>)list2) && !RaceRestrictionSettings.CanWear(((Thing)apparel).def, ((Thing)pawn).def))
				{
					foreach (FloatMenuOption item3 in list2)
					{
						int index3 = opts.IndexOf(item3);
						opts.Remove(item3);
						opts.Insert(index3, (FloatMenuOption)(object)new FloatMenuOption(TranslatorFormattedStringExtensions.Translate("CannotWear", NamedArgument.op_Implicit(((Entity)apparel).get_LabelShort()), NamedArgument.op_Implicit((Thing)(object)apparel)) + " (" + ((Def)((Thing)pawn).def).get_LabelCap() + " can't wear this)", (Action)null, (MenuOptionPriority)4, (Action)null, (Thing)null, 0f, (Func<Rect, bool>)null, (WorldObject)null));
					}
				}
			}
		}

		public static void CanGetThoughtPostfix(ref bool __result, ThoughtDef def, Pawn pawn)
		{
			if (!__result)
			{
				return;
			}
			__result = !ThoughtSettings.thoughtRestrictionDict.TryGetValue(def, out List<ThingDef_AlienRace> value);
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result = (value?.Contains(thingDef_AlienRace) ?? true);
				def = thingDef_AlienRace.alienRace.thoughtSettings.ReplaceIfApplicable(def);
				if ((thingDef_AlienRace.alienRace.thoughtSettings.cannotReceiveThoughtsAtAll && !(thingDef_AlienRace.alienRace.thoughtSettings.canStillReceiveThoughts?.Contains(((Def)def).defName) ?? false)) || (thingDef_AlienRace.alienRace.thoughtSettings.cannotReceiveThoughts?.Contains(((Def)def).defName) ?? false))
				{
					__result = false;
				}
			}
		}

		public static void CanDoNextStartPawnPostfix(ref bool __result)
		{
			if (!__result)
			{
				bool result = true;
				Find.get_GameInitData().startingAndOptionalPawns.ForEach(delegate(Pawn current)
				{
					//IL_0019: Unknown result type (might be due to invalid IL or missing references)
					if (!current.get_Name().get_IsValid() && ((Thing)current).def.race.GetNameGenerator(current.gender) == null)
					{
						result = false;
					}
				});
				__result = result;
			}
		}

		public static bool GeneratePawnNamePrefix(ref Name __result, Pawn pawn, NameStyle style = 0, string forcedLastName = null)
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Expected O, but got Unknown
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace == null || ((ThingDef)thingDef_AlienRace).race.GetNameGenerator(pawn.gender) == null || (int)style != 0)
			{
				return true;
			}
			NameTriple val = NameTriple.FromString(NameGenerator.GenerateName(((ThingDef)thingDef_AlienRace).race.GetNameGenerator(pawn.gender), (Predicate<string>)null, false, (string)null, (string)null));
			string first = val.get_First();
			string text = val.get_Nick();
			string text2 = val.get_Last();
			if (text == null)
			{
				text = val.get_First();
			}
			if (text2 != null && forcedLastName != null)
			{
				text2 = forcedLastName;
			}
			__result = (Name)(object)new NameTriple(first ?? string.Empty, text ?? string.Empty, text2 ?? string.Empty);
			return false;
		}

		public static void GenerateRandomAgePrefix(Pawn pawn, PawnGenerationRequest request)
		{
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			if (((PawnGenerationRequest)(ref request)).get_FixedGender().HasValue || !pawn.get_RaceProps().hasGenders)
			{
				return;
			}
			Info modExtension = ((Def)pawn.kindDef).GetModExtension<Info>();
			float? num = (modExtension != null) ? new float?(modExtension.maleGenderProbability) : (((Thing)pawn).def as ThingDef_AlienRace)?.alienRace.generalSettings.maleGenderProbability;
			if (num.HasValue)
			{
				pawn.gender = (Gender)((!(Rand.get_Value() >= num)) ? 1 : 2);
				AlienPartGenerator.AlienComp alienComp = ThingCompUtility.TryGetComp<AlienPartGenerator.AlienComp>((Thing)(object)pawn);
				if (((alienComp != null && Math.Abs(num.Value) < 0.001f) || Math.Abs(num.Value - 1f) < 0.001f) && alienComp != null)
				{
					alienComp.fixGenderPostSpawn = true;
				}
			}
		}

		public static void GiveAppropriateBioAndNameToPostfix(Pawn pawn)
		{
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Unknown result type (might be due to invalid IL or missing references)
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Unknown result type (might be due to invalid IL or missing references)
			//IL_0105: Unknown result type (might be due to invalid IL or missing references)
			//IL_0192: Unknown result type (might be due to invalid IL or missing references)
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				if (thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienhaircolorgen != null)
				{
					pawn.story.hairColor = thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienhaircolorgen.NewRandomizedColor();
				}
				else if (thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.useSkincolorForHair && thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienskincolorgen != null)
				{
					pawn.story.hairColor = pawn.story.get_SkinColor();
				}
				AlienPartGenerator.AlienComp comp = ((ThingWithComps)pawn).GetComp<AlienPartGenerator.AlienComp>();
				ColorGenerator alienhairsecondcolorgen = thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienhairsecondcolorgen;
				comp.hairColorSecond = ((alienhairsecondcolorgen != null) ? alienhairsecondcolorgen.NewRandomizedColor() : pawn.story.hairColor);
				if (thingDef_AlienRace.alienRace.hairSettings.getsGreyAt <= pawn.ageTracker.get_AgeBiologicalYears())
				{
					float num = Rand.Range(0.65f, 0.85f);
					pawn.story.hairColor = new Color(num, num, num);
				}
				string head = thingDef_AlienRace.alienRace.graphicPaths.GetCurrentGraphicPath(pawn.ageTracker.get_CurLifeStage()).head;
				Traverse.Create(pawn.story).Field("headGraphicPath").SetValue(GenText.NullOrEmpty(thingDef_AlienRace.alienRace.graphicPaths.GetCurrentGraphicPath(pawn.ageTracker.get_CurLifeStage()).head) ? "" : thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.RandomAlienHead(head, pawn));
				pawn.story.crownType = (CrownType)1;
			}
		}

		public static bool NewGeneratedStartingPawnPrefix(ref Pawn __result)
		{
			//IL_013c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0159: Unknown result type (might be due to invalid IL or missing references)
			PawnKindDef kindDef = Faction.get_OfPlayer().def.basicMemberKind;
			GenCollection.InRandomOrder<PawnKindEntry>((from sce in (from tdar in DefDatabase<RaceSettings>.get_AllDefsListForReading()
					where !GenList.NullOrEmpty<FactionPawnKindEntry>((IList<FactionPawnKindEntry>)tdar.pawnKindSettings.startingColonists)
					select tdar).SelectMany((RaceSettings tdar) => tdar.pawnKindSettings.startingColonists)
				where sce.factionDefs.Contains(((Def)Faction.get_OfPlayer().def).defName)
				select sce).SelectMany((FactionPawnKindEntry sce) => sce.pawnKindEntries), (IList<PawnKindEntry>)null).ToList().ForEach(delegate(PawnKindEntry pke)
			{
				if (Rand.Range(0f, 100f) < pke.chance)
				{
					PawnKindDef namedSilentFail = DefDatabase<PawnKindDef>.GetNamedSilentFail(GenCollection.RandomElement<string>((IEnumerable<string>)pke.kindDefs));
					if (namedSilentFail != null)
					{
						kindDef = namedSilentFail;
					}
				}
			});
			if (kindDef == Faction.get_OfPlayer().def.basicMemberKind)
			{
				return true;
			}
			PawnGenerationRequest val = default(PawnGenerationRequest);
			((PawnGenerationRequest)(ref val))._002Ector(kindDef, Faction.get_OfPlayer(), (PawnGenerationContext)1, -1, true, false, false, false, true, false, 26f, false, true, true, false, false, false, false, (Predicate<Pawn>)null, (Predicate<Pawn>)null, (float?)null, (float?)null, (float?)null, (Gender?)null, (float?)null, (string)null);
			Pawn val2;
			try
			{
				val2 = PawnGenerator.GeneratePawn(val);
			}
			catch (Exception arg)
			{
				Log.Error($"There was an exception thrown by the PawnGenerator during generating a starting pawn. Trying one more time...\nException: {arg}", false);
				val2 = PawnGenerator.GeneratePawn(val);
			}
			val2.relations.everSeenByPlayer = true;
			PawnComponentsUtility.AddComponentsForSpawn(val2);
			__result = val2;
			return false;
		}

		public static void RandomHediffsToGainOnBirthdayPostfix(ref IEnumerable<HediffGiver_Birthday> __result, ThingDef raceDef)
		{
			if ((raceDef as ThingDef_AlienRace)?.alienRace.generalSettings.immuneToAge ?? false)
			{
				__result = new List<HediffGiver_Birthday>();
			}
		}

		public static bool GenerateRandomOldAgeInjuriesPrefix(Pawn pawn)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null && thingDef_AlienRace.alienRace.generalSettings.immuneToAge)
			{
				return false;
			}
			return true;
		}

		public static bool FillBackstoryInSlotShuffledPrefix(Pawn pawn, BackstorySlot slot, ref Backstory backstory)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Invalid comparison between Unknown and I4
			bioReference = null;
			if ((int)slot == 1)
			{
				string text = DefDatabase<BackstoryDef>.GetNamedSilentFail(pawn.story.childhood.identifier)?.linkedBackstory;
				if (text != null && BackstoryDatabase.TryGetWithIdentifier(text, ref backstory, true))
				{
					return false;
				}
			}
			return true;
		}

		public static IEnumerable<CodeInstruction> FillBackstoryInSlotShuffledTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			MethodInfo shuffleableInfo = AccessTools.Method(typeof(BackstoryDatabase), "ShuffleableBackstoryList");
			foreach (CodeInstruction codeInstruction in instructions)
			{
				yield return codeInstruction;
				if (codeInstruction.opcode == OpCodes.Call && codeInstruction.operand == shuffleableInfo)
				{
					yield return new CodeInstruction(OpCodes.Ldarg_1);
					yield return new CodeInstruction(OpCodes.Ldsfld, AccessTools.Method(typeof(PawnBioAndNameGenerator), "tmpBackstories"));
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "FilterBackstories"));
				}
			}
		}

		public static void FilterBackstories(BackstorySlot slot, List<Backstory> tmpBackstories)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Invalid comparison between Unknown and I4
			if ((int)slot == 1)
			{
				tmpBackstories = tmpBackstories.Where(delegate(Backstory bs)
				{
					BackstoryDef namedSilentFail = DefDatabase<BackstoryDef>.GetNamedSilentFail(bs.identifier);
					return namedSilentFail == null || GenText.NullOrEmpty(namedSilentFail.linkedBackstory);
				}).ToList();
			}
		}

		public static void TryGetRandomUnusedSolidBioForPostfix(List<string> backstoryCategories, ref PawnBio __result, PawnKindDef kind, Gender gender, string requiredLastName)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			PawnBio bio = default(PawnBio);
			if (GenCollection.TryRandomElement<PawnBio>(SolidBioDatabase.allBios.Where((PawnBio pb) => ((((kind.race as ThingDef_AlienRace)?.alienRace.generalSettings.allowHumanBios ?? true) && (((Def)kind).GetModExtension<Info>()?.allowHumanBios ?? true)) || (DefDatabase<PawnBioDef>.get_AllDefs().FirstOrDefault((PawnBioDef pbd) => ((Name)pb.name).ConfusinglySimilarTo((Name)(object)pbd.name))?.validRaces.Contains(kind.race) ?? false)) && ((int)pb.gender == 2 || ((int)pb.gender == 0 && (int)gender == 1)) && (GenText.NullOrEmpty(requiredLastName) || pb.name.get_Last() == requiredLastName) && (!kind.factionLeader || pb.pirateKing) && GenCollection.Any<string>(pb.adulthood.spawnCategories, (Predicate<string>)backstoryCategories.Contains) && !((Name)pb.name).get_UsedThisGame()), ref bio))
			{
				__result = bio;
				bioReference = DefDatabase<PawnBioDef>.get_AllDefs().FirstOrDefault((PawnBioDef pbd) => ((Name)bio.name).ConfusinglySimilarTo((Name)(object)pbd.name));
			}
			else
			{
				__result = null;
			}
		}

		public static bool ResolveAllGraphicsPrefix(PawnGraphicSet __instance)
		{
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_011c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0121: Unknown result type (might be due to invalid IL or missing references)
			//IL_0128: Unknown result type (might be due to invalid IL or missing references)
			//IL_012d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0261: Unknown result type (might be due to invalid IL or missing references)
			//IL_0278: Unknown result type (might be due to invalid IL or missing references)
			//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0432: Unknown result type (might be due to invalid IL or missing references)
			//IL_0437: Unknown result type (might be due to invalid IL or missing references)
			//IL_0474: Unknown result type (might be due to invalid IL or missing references)
			//IL_0479: Unknown result type (might be due to invalid IL or missing references)
			//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_050f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0515: Unknown result type (might be due to invalid IL or missing references)
			//IL_052d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0538: Unknown result type (might be due to invalid IL or missing references)
			//IL_054f: Unknown result type (might be due to invalid IL or missing references)
			//IL_057a: Unknown result type (might be due to invalid IL or missing references)
			//IL_057f: Unknown result type (might be due to invalid IL or missing references)
			//IL_065e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0663: Unknown result type (might be due to invalid IL or missing references)
			//IL_0679: Unknown result type (might be due to invalid IL or missing references)
			//IL_067e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0699: Unknown result type (might be due to invalid IL or missing references)
			//IL_069e: Unknown result type (might be due to invalid IL or missing references)
			//IL_06b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_06b9: Unknown result type (might be due to invalid IL or missing references)
			Pawn pawn = __instance.pawn;
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				AlienPartGenerator.AlienComp comp = ((ThingWithComps)__instance.pawn).GetComp<AlienPartGenerator.AlienComp>();
				if (comp.fixGenderPostSpawn)
				{
					__instance.pawn.gender = (Gender)((!(Rand.get_Value() >= thingDef_AlienRace.alienRace.generalSettings.maleGenderProbability)) ? 1 : 2);
					__instance.pawn.set_Name(PawnBioAndNameGenerator.GeneratePawnName(__instance.pawn, (NameStyle)0, (string)null));
					Traverse.Create(__instance.pawn.story).Field("headGraphicPath").SetValue(GenText.NullOrEmpty(thingDef_AlienRace.alienRace.graphicPaths.GetCurrentGraphicPath(pawn.ageTracker.get_CurLifeStage()).head) ? "" : thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.RandomAlienHead(thingDef_AlienRace.alienRace.graphicPaths.GetCurrentGraphicPath(pawn.ageTracker.get_CurLifeStage()).head, __instance.pawn));
					comp.fixGenderPostSpawn = false;
				}
				GraphicPaths currentGraphicPath = thingDef_AlienRace.alienRace.graphicPaths.GetCurrentGraphicPath(pawn.ageTracker.get_CurLifeStage());
				comp.customDrawSize = currentGraphicPath.customDrawSize;
				comp.customPortraitDrawSize = currentGraphicPath.customPortraitDrawSize;
				comp.AssignProperMeshs();
				Traverse.Create(pawn.story).Field("headGraphicPath").SetValue(GenText.NullOrEmpty(comp.crownType) ? thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.RandomAlienHead(currentGraphicPath.head, pawn) : AlienPartGenerator.GetAlienHead(currentGraphicPath.head, thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.useGenderedHeads ? ((object)(Gender)(ref pawn.gender)).ToString() : "", comp.crownType));
				__instance.nakedGraphic = ((!GenText.NullOrEmpty(currentGraphicPath.body)) ? thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.GetNakedGraphic(pawn.story.bodyType, ((Object)(object)ContentFinder<Texture2D>.Get(AlienPartGenerator.GetNakedPath(pawn.story.bodyType, currentGraphicPath.body, thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.useGenderedBodies ? ((object)(Gender)(ref pawn.gender)).ToString() : "") + "_northm", false) == (Object)null) ? ShaderDatabase.Cutout : ShaderDatabase.CutoutComplex, __instance.pawn.story.get_SkinColor(), thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.SkinColor(pawn, first: false), currentGraphicPath.body, ((object)(Gender)(ref pawn.gender)).ToString()) : null);
				__instance.rottingGraphic = ((!GenText.NullOrEmpty(currentGraphicPath.body)) ? thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.GetNakedGraphic(pawn.story.bodyType, ShaderDatabase.Cutout, PawnGraphicSet.RottingColor, PawnGraphicSet.RottingColor, currentGraphicPath.body, ((object)(Gender)(ref pawn.gender)).ToString()) : null);
				__instance.dessicatedGraphic = ((!GenText.NullOrEmpty(currentGraphicPath.skeleton)) ? GraphicDatabase.Get<Graphic_Multi>((currentGraphicPath.skeleton == "Things/Pawn/Humanlike/HumanoidDessicated") ? pawn.story.bodyType.bodyDessicatedGraphicPath : currentGraphicPath.skeleton, ShaderDatabase.Cutout) : null);
				object headGraphic;
				if (!pawn.health.hediffSet.get_HasHead() || GenText.NullOrEmpty(pawn.story.get_HeadGraphicPath()))
				{
					headGraphic = null;
				}
				else
				{
					string headGraphicPath = pawn.story.get_HeadGraphicPath();
					object obj;
					if (!((Object)(object)ContentFinder<Texture2D>.Get(pawn.story.get_HeadGraphicPath() + "_northm", false) == (Object)null))
					{
						obj = ShaderDatabase.CutoutComplex;
					}
					else
					{
						ShaderTypeDef shader = thingDef_AlienRace.alienRace.hairSettings.shader;
						obj = (((shader != null) ? shader.get_Shader() : null) ?? ShaderDatabase.Cutout);
					}
					headGraphic = GraphicDatabase.Get<Graphic_Multi>(headGraphicPath, (Shader)obj, Vector2.get_one(), pawn.story.get_SkinColor(), thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.SkinColor(pawn, first: false));
				}
				__instance.headGraphic = (Graphic)headGraphic;
				__instance.desiccatedHeadGraphic = ((pawn.health.hediffSet.get_HasHead() && !GenText.NullOrEmpty(pawn.story.get_HeadGraphicPath())) ? GraphicDatabase.Get<Graphic_Multi>(pawn.story.get_HeadGraphicPath(), ShaderDatabase.Cutout, Vector2.get_one(), PawnGraphicSet.RottingColor) : null);
				__instance.skullGraphic = ((pawn.health.hediffSet.get_HasHead() && !GenText.NullOrEmpty(currentGraphicPath.skull)) ? GraphicDatabase.Get<Graphic_Multi>(currentGraphicPath.skull, ShaderDatabase.Cutout, Vector2.get_one(), Color.get_white()) : null);
				__instance.hairGraphic = GraphicDatabase.Get<Graphic_Multi>(__instance.pawn.story.hairDef.texPath, ((Object)(object)ContentFinder<Texture2D>.Get(__instance.pawn.story.hairDef.texPath + "_northm", false) == (Object)null) ? ShaderDatabase.Cutout : ShaderDatabase.CutoutComplex, Vector2.get_one(), pawn.story.hairColor, comp.hairColorSecond);
				__instance.headStumpGraphic = ((!GenText.NullOrEmpty(currentGraphicPath.stump)) ? GraphicDatabase.Get<Graphic_Multi>(currentGraphicPath.stump, (comp.skinColor == comp.skinColorSecond) ? ShaderDatabase.Cutout : ShaderDatabase.CutoutComplex, Vector2.get_one(), pawn.story.get_SkinColor(), thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.SkinColor(pawn, first: false)) : null);
				__instance.desiccatedHeadStumpGraphic = ((!GenText.NullOrEmpty(currentGraphicPath.stump)) ? GraphicDatabase.Get<Graphic_Multi>(currentGraphicPath.stump, ShaderDatabase.Cutout, Vector2.get_one(), PawnGraphicSet.RottingColor) : null);
				AlienPartGenerator alienPartGenerator = thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator;
				comp.addonGraphics = new List<Graphic>();
				if (comp.addonVariants == null)
				{
					comp.addonVariants = new List<int>();
				}
				int sharedIndex = 0;
				for (int i = 0; i < alienPartGenerator.bodyAddons.Count; i++)
				{
					Graphic path = alienPartGenerator.bodyAddons[i].GetPath(pawn, ref sharedIndex, (comp.addonVariants.Count > i) ? new int?(comp.addonVariants[i]) : null);
					comp.addonGraphics.Add(path);
					if (comp.addonVariants.Count <= i)
					{
						comp.addonVariants.Add(sharedIndex);
					}
				}
				comp.ColorChannels["skin"].first = comp.skinColor;
				comp.ColorChannels["skin"].second = comp.skinColorSecond;
				comp.ColorChannels["hair"].first = pawn.story.hairColor;
				comp.ColorChannels["hair"].second = comp.hairColorSecond;
				__instance.ResolveApparelGraphics();
				return false;
			}
			return true;
		}

		public static void GenerateTraitsPrefix(Pawn pawn, PawnGenerationRequest request)
		{
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			if (!((PawnGenerationRequest)(ref request)).get_Newborn() && ((PawnGenerationRequest)(ref request)).get_CanGeneratePawnRelations() && pawn.story.get_AllBackstories().Any((Backstory bs) => DefDatabase<BackstoryDef>.GetNamedSilentFail(bs.identifier)?.relationSettings != null))
			{
				pawn.relations.ClearAllRelations();
				AccessTools.Method(typeof(PawnGenerator), "GeneratePawnRelations").Invoke(null, new object[2]
				{
					pawn,
					request
				});
			}
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null && !GenList.NullOrEmpty<AlienTraitEntry>((IList<AlienTraitEntry>)thingDef_AlienRace.alienRace.generalSettings.forcedRaceTraitEntries))
			{
				thingDef_AlienRace.alienRace.generalSettings.forcedRaceTraitEntries.ForEach(delegate(AlienTraitEntry ate)
				{
					//IL_0030: Unknown result type (might be due to invalid IL or missing references)
					//IL_0036: Invalid comparison between Unknown and I4
					//IL_0071: Unknown result type (might be due to invalid IL or missing references)
					//IL_0077: Invalid comparison between Unknown and I4
					//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
					//IL_010e: Unknown result type (might be due to invalid IL or missing references)
					//IL_0118: Expected O, but got Unknown
					if (((pawn.story.traits.allTraits.Count < 4 && (int)pawn.gender == 1 && (Math.Abs(ate.commonalityMale - -1f) < 0.001f || (float)Rand.Range(0, 100) < ate.commonalityMale)) || ((int)pawn.gender == 2 && (!(Math.Abs(ate.commonalityFemale - -1f) > 0.001f) || (float)Rand.Range(0, 100) < ate.commonalityFemale)) || (int)pawn.gender == 0) && !GenCollection.Any<Trait>(pawn.story.traits.allTraits, (Predicate<Trait>)((Trait tr) => GenText.EqualsIgnoreCase(((Def)tr.def).defName, ate.defName))))
					{
						pawn.story.traits.GainTrait((Trait)(object)new Trait(TraitDef.Named(ate.defName), ate.degree, true));
					}
				});
			}
		}

		public static void SkinColorPostfix(Pawn_StoryTracker __instance, ref Color __result)
		{
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			Pawn value = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)value).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				__result = thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.SkinColor(value);
			}
		}

		public static void GenerateBodyTypePostfix(ref Pawn pawn)
		{
			if (BackstoryDef.checkBodyType.Contains(pawn.story.GetBackstory((BackstorySlot)1)))
			{
				pawn.story.bodyType = DefDatabase<BodyTypeDef>.GetRandom();
			}
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null && !GenList.NullOrEmpty<BodyTypeDef>((IList<BodyTypeDef>)thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienbodytypes) && !thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienbodytypes.Contains(pawn.story.bodyType))
			{
				pawn.story.bodyType = GenCollection.RandomElement<BodyTypeDef>((IEnumerable<BodyTypeDef>)thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.alienbodytypes);
			}
		}

		public static void RandomHairDefForPrefix(Pawn pawn, ref FactionDef factionType)
		{
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace != null)
			{
				if (!thingDef_AlienRace.alienRace.hairSettings.hasHair)
				{
					factionType = noHairFaction;
				}
				else if (!GenList.NullOrEmpty<string>((IList<string>)thingDef_AlienRace.alienRace.hairSettings.hairTags))
				{
					hairFaction.hairTags = thingDef_AlienRace.alienRace.hairSettings.hairTags;
					factionType = hairFaction;
				}
			}
		}

		public static void GeneratePawnPrefix(ref PawnGenerationRequest request)
		{
			//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_033b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0340: Unknown result type (might be due to invalid IL or missing references)
			PawnKindDef kindDef = ((PawnGenerationRequest)(ref request)).get_KindDef();
			if (Faction.get_OfPlayerSilentFail() != null && kindDef == PawnKindDefOf.Villager && ((PawnGenerationRequest)(ref request)).get_Faction().get_IsPlayer() && kindDef.race != Faction.get_OfPlayer()?.def.basicMemberKind.race)
			{
				kindDef = Faction.get_OfPlayer()?.def.basicMemberKind;
			}
			if (Rand.get_Value() <= 0.4f)
			{
				IEnumerable<RaceSettings> allDefsListForReading = DefDatabase<RaceSettings>.get_AllDefsListForReading();
				PawnKindEntry pawnKindEntry = default(PawnKindEntry);
				if (((PawnGenerationRequest)(ref request)).get_KindDef() == PawnKindDefOf.SpaceRefugee)
				{
					if (GenCollection.TryRandomElementByWeight<PawnKindEntry>(from r in allDefsListForReading
						where !GenList.NullOrEmpty<PawnKindEntry>((IList<PawnKindEntry>)r.pawnKindSettings.alienrefugeekinds)
						select GenCollection.RandomElement<PawnKindEntry>((IEnumerable<PawnKindEntry>)r.pawnKindSettings.alienrefugeekinds), (Func<PawnKindEntry, float>)((PawnKindEntry pke) => pke.chance), ref pawnKindEntry))
					{
						PawnKindDef namedSilentFail = DefDatabase<PawnKindDef>.GetNamedSilentFail(GenCollection.RandomElement<string>((IEnumerable<string>)pawnKindEntry.kindDefs));
						if (namedSilentFail != null)
						{
							kindDef = namedSilentFail;
						}
					}
				}
				else if (((PawnGenerationRequest)(ref request)).get_KindDef() == PawnKindDefOf.Slave)
				{
					if (GenCollection.TryRandomElementByWeight<PawnKindEntry>(from r in allDefsListForReading
						where !GenList.NullOrEmpty<PawnKindEntry>((IList<PawnKindEntry>)r.pawnKindSettings.alienslavekinds)
						select GenCollection.RandomElement<PawnKindEntry>((IEnumerable<PawnKindEntry>)r.pawnKindSettings.alienslavekinds), (Func<PawnKindEntry, float>)((PawnKindEntry pke) => pke.chance), ref pawnKindEntry))
					{
						PawnKindDef namedSilentFail2 = DefDatabase<PawnKindDef>.GetNamedSilentFail(GenCollection.RandomElement<string>((IEnumerable<string>)pawnKindEntry.kindDefs));
						if (namedSilentFail2 != null)
						{
							kindDef = namedSilentFail2;
						}
					}
				}
				else if (((PawnGenerationRequest)(ref request)).get_KindDef() == PawnKindDefOf.Villager)
				{
					GenCollection.InRandomOrder<PawnKindEntry>((from sce in (from tdar in DefDatabase<RaceSettings>.get_AllDefsListForReading()
							where !GenList.NullOrEmpty<FactionPawnKindEntry>((IList<FactionPawnKindEntry>)tdar.pawnKindSettings.alienwandererkinds)
							select tdar).SelectMany((RaceSettings tdar) => tdar.pawnKindSettings.alienwandererkinds)
						where sce.factionDefs.Contains(((Def)Faction.get_OfPlayer().def).defName)
						select sce).SelectMany((FactionPawnKindEntry sce) => sce.pawnKindEntries), (IList<PawnKindEntry>)null).ToList().ForEach(delegate(PawnKindEntry pke)
					{
						if (Rand.Range(0f, 100f) < pke.chance)
						{
							PawnKindDef namedSilentFail3 = DefDatabase<PawnKindDef>.GetNamedSilentFail(GenCollection.RandomElement<string>((IEnumerable<string>)pke.kindDefs));
							if (namedSilentFail3 != null)
							{
								kindDef = namedSilentFail3;
							}
						}
					});
				}
			}
			request = new PawnGenerationRequest(kindDef, ((PawnGenerationRequest)(ref request)).get_Faction(), ((PawnGenerationRequest)(ref request)).get_Context(), ((PawnGenerationRequest)(ref request)).get_Tile(), ((PawnGenerationRequest)(ref request)).get_ForceGenerateNewPawn(), ((PawnGenerationRequest)(ref request)).get_Newborn(), ((PawnGenerationRequest)(ref request)).get_AllowDead(), ((PawnGenerationRequest)(ref request)).get_AllowDead(), ((PawnGenerationRequest)(ref request)).get_CanGeneratePawnRelations(), ((PawnGenerationRequest)(ref request)).get_MustBeCapableOfViolence(), ((PawnGenerationRequest)(ref request)).get_ColonistRelationChanceFactor(), ((PawnGenerationRequest)(ref request)).get_ForceAddFreeWarmLayerIfNeeded(), ((PawnGenerationRequest)(ref request)).get_AllowGay(), ((PawnGenerationRequest)(ref request)).get_AllowFood(), ((PawnGenerationRequest)(ref request)).get_Inhabitant(), ((PawnGenerationRequest)(ref request)).get_CertainlyBeenInCryptosleep(), ((PawnGenerationRequest)(ref request)).get_ForceRedressWorldPawnIfFormerColonist(), ((PawnGenerationRequest)(ref request)).get_WorldPawnFactionDoesntMatter(), ((PawnGenerationRequest)(ref request)).get_ValidatorPreGear(), ((PawnGenerationRequest)(ref request)).get_ValidatorPostGear(), ((PawnGenerationRequest)(ref request)).get_MinChanceToRedressWorldPawn(), ((PawnGenerationRequest)(ref request)).get_FixedBiologicalAge(), ((PawnGenerationRequest)(ref request)).get_FixedChronologicalAge(), ((PawnGenerationRequest)(ref request)).get_FixedGender(), ((PawnGenerationRequest)(ref request)).get_FixedMelanin(), ((PawnGenerationRequest)(ref request)).get_FixedLastName());
		}

		public static IEnumerable<CodeInstruction> RenderPawnInternalTranspiler(IEnumerable<CodeInstruction> instructions)
		{
			FieldInfo humanlikeBodyInfo = AccessTools.Field(typeof(MeshPool), "humanlikeBodySet");
			FieldInfo humanlikeHeadInfo = AccessTools.Field(typeof(MeshPool), "humanlikeHeadSet");
			MethodInfo hairInfo = AccessTools.Property(typeof(PawnGraphicSet), "HairMeshSet").GetGetMethod();
			List<CodeInstruction> instructionList = instructions.ToList();
			for (int i = 0; i < instructionList.Count; i++)
			{
				CodeInstruction codeInstruction = instructionList[i];
				if (codeInstruction.operand == humanlikeBodyInfo)
				{
					instructionList.RemoveRange(i, 2);
					yield return new CodeInstruction(OpCodes.Ldarg_S, 7);
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PawnRenderer), "pawn"));
					yield return new CodeInstruction(OpCodes.Ldarg_S, 4);
					yield return new CodeInstruction(OpCodes.Ldc_I4_1);
					codeInstruction = new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "GetPawnMesh"));
				}
				else if (codeInstruction.operand == humanlikeHeadInfo)
				{
					instructionList.RemoveRange(i, 2);
					yield return new CodeInstruction(OpCodes.Ldarg_S, 7);
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PawnRenderer), "pawn"));
					yield return new CodeInstruction(OpCodes.Ldarg_S, 5);
					yield return new CodeInstruction(OpCodes.Ldc_I4_0);
					codeInstruction = new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "GetPawnMesh"));
				}
				else if (i + 4 < instructionList.Count && instructionList[i + 2].operand == hairInfo)
				{
					yield return new CodeInstruction(OpCodes.Ldarg_S, 7)
					{
						labels = codeInstruction.labels
					};
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PawnRenderer), "pawn"));
					yield return new CodeInstruction(OpCodes.Ldarg_S, 5);
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PawnRenderer), "graphics"));
					codeInstruction = new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "GetPawnHairMesh"));
					instructionList.RemoveRange(i, 4);
				}
				else if (i > 1 && instructionList[i - 1].operand == AccessTools.Method(typeof(Graphics), "DrawMesh", new Type[5]
				{
					typeof(Mesh),
					typeof(Vector3),
					typeof(Quaternion),
					typeof(Material),
					typeof(int)
				}) && i + 1 < instructionList.Count && instructionList[i + 1].opcode == OpCodes.Brtrue)
				{
					yield return codeInstruction;
					yield return new CodeInstruction(OpCodes.Ldarg_1);
					yield return new CodeInstruction(OpCodes.Ldarg_0);
					yield return new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PawnRenderer), "pawn"));
					yield return new CodeInstruction(OpCodes.Ldloc_0);
					yield return new CodeInstruction(OpCodes.Ldarg_S, 4);
					yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(patchType, "DrawAddons"));
					codeInstruction = new CodeInstruction(OpCodes.Ldarg_S, 7);
				}
				yield return codeInstruction;
			}
		}

		public static Mesh GetPawnMesh(bool portrait, Pawn pawn, Rot4 facing, bool wantsBody)
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			AlienPartGenerator.AlienComp comp = ((ThingWithComps)pawn).GetComp<AlienPartGenerator.AlienComp>();
			if (comp == null)
			{
				if (!wantsBody)
				{
					return MeshPool.humanlikeHeadSet.MeshAt(facing);
				}
				return MeshPool.humanlikeBodySet.MeshAt(facing);
			}
			if (!portrait)
			{
				if (!wantsBody)
				{
					return comp.alienGraphics.headSet.MeshAt(facing);
				}
				return comp.alienGraphics.bodySet.MeshAt(facing);
			}
			if (!wantsBody)
			{
				return comp.alienPortraitGraphics.headSet.MeshAt(facing);
			}
			return comp.alienPortraitGraphics.bodySet.MeshAt(facing);
		}

		public static Mesh GetPawnHairMesh(bool portrait, Pawn pawn, Rot4 headFacing, PawnGraphicSet graphics)
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			AlienPartGenerator.AlienComp comp = ((ThingWithComps)pawn).GetComp<AlienPartGenerator.AlienComp>();
			if (comp == null)
			{
				return graphics.get_HairMeshSet().MeshAt(headFacing);
			}
			return (portrait ? comp.alienPortraitGraphics.hairSetAverage : comp.alienGraphics.hairSetAverage).MeshAt(headFacing);
		}

		public static void DrawAddons(bool portrait, Vector3 vector, Pawn pawn, Quaternion quat, Rot4 rotation)
		{
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_006d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0087: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0146: Unknown result type (might be due to invalid IL or missing references)
			//IL_015b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0164: Unknown result type (might be due to invalid IL or missing references)
			//IL_0169: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0202: Unknown result type (might be due to invalid IL or missing references)
			//IL_0207: Unknown result type (might be due to invalid IL or missing references)
			//IL_0247: Unknown result type (might be due to invalid IL or missing references)
			//IL_0249: Unknown result type (might be due to invalid IL or missing references)
			//IL_027a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0281: Unknown result type (might be due to invalid IL or missing references)
			//IL_028e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0295: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_02de: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0301: Unknown result type (might be due to invalid IL or missing references)
			//IL_0308: Unknown result type (might be due to invalid IL or missing references)
			//IL_030d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0312: Unknown result type (might be due to invalid IL or missing references)
			//IL_0313: Unknown result type (might be due to invalid IL or missing references)
			//IL_0329: Unknown result type (might be due to invalid IL or missing references)
			ThingDef_AlienRace thingDef_AlienRace = ((Thing)pawn).def as ThingDef_AlienRace;
			if (thingDef_AlienRace == null)
			{
				return;
			}
			List<AlienPartGenerator.BodyAddon> bodyAddons = thingDef_AlienRace.alienRace.generalSettings.alienPartGenerator.bodyAddons;
			AlienPartGenerator.AlienComp alienComp = ((ThingWithComps)pawn).GetComp<AlienPartGenerator.AlienComp>();
			Vector3 val3 = default(Vector3);
			for (int i = 0; i < bodyAddons.Count; i++)
			{
				AlienPartGenerator.BodyAddon bodyAddon = bodyAddons[i];
				if (!bodyAddon.CanDrawAddon(pawn))
				{
					continue;
				}
				AlienPartGenerator.RotationOffset rotationOffset = (rotation == Rot4.get_South()) ? bodyAddon.offsets.south : ((rotation == Rot4.get_North()) ? bodyAddon.offsets.north : ((rotation == Rot4.get_East()) ? bodyAddon.offsets.east : bodyAddon.offsets.west));
				Vector2 val = (Vector2)(((_003F?)((!portrait) ? rotationOffset?.bodyTypes : (rotationOffset?.portraitBodyTypes ?? rotationOffset?.bodyTypes))?.FirstOrDefault((AlienPartGenerator.BodyTypeOffset to) => to.bodyType == pawn.story.bodyType)?.offset) ?? Vector2.get_zero());
				Vector2 val2 = (Vector2)(((_003F?)((!portrait) ? rotationOffset?.crownTypes : (rotationOffset?.portraitCrownTypes ?? rotationOffset?.crownTypes))?.FirstOrDefault((AlienPartGenerator.CrownTypeOffset to) => to.crownType == alienComp.crownType)?.offset) ?? Vector2.get_zero());
				float num = 0.42f;
				float num2 = -0.22f;
				float num3 = bodyAddon.inFrontOfBody ? (0.3f + bodyAddon.layerOffset) : (-0.3f - bodyAddon.layerOffset);
				float num4 = bodyAddon.angle;
				if (rotation == Rot4.get_North())
				{
					num = 0f;
					if (bodyAddon.layerInvert)
					{
						num3 = 0f - num3;
					}
					num2 = -0.55f;
					num4 = 0f;
				}
				num += val.x + val2.x;
				num2 += val.y + val2.y;
				if (rotation == Rot4.get_East())
				{
					num = 0f - num;
					num4 = 0f - num4;
				}
				((Vector3)(ref val3))._002Ector(num, num3, num2);
				GenDraw.DrawMeshNowOrLater(alienComp.addonGraphics[i].MeshAt(rotation), vector + Vector3Utility.RotatedBy(val3, Mathf.Acos(Quaternion.Dot(Quaternion.get_identity(), quat)) * 2f * 57.29578f), Quaternion.AngleAxis(num4, Vector3.get_up()) * quat, alienComp.addonGraphics[i].MatAt(rotation, (Thing)null), portrait);
			}
		}
	}
}
