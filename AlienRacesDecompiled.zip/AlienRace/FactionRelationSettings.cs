using System.Collections.Generic;
using Verse;

namespace AlienRace
{
	public class FactionRelationSettings
	{
		public List<string> factions;

		public IntRange goodwill;
	}
}
