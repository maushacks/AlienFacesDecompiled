using System.Collections.Generic;
using Verse;

namespace AlienRace
{
	public class HairSettings
	{
		public bool hasHair = true;

		public List<string> hairTags;

		public int getsGreyAt = 40;

		public ShaderTypeDef shader;
	}
}
