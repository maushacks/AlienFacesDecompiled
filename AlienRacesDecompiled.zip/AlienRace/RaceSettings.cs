using RimWorld;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace AlienRace
{
	[StaticConstructorOnStartup]
	public class RaceSettings : Def
	{
		public PawnKindSettings pawnKindSettings;

		public List<BackstoryTagItem> backstoryTagInsertion;

		static RaceSettings()
		{
			foreach (BackstoryTagItem item in DefDatabase<RaceSettings>.get_AllDefs().SelectMany((RaceSettings rs) => rs.backstoryTagInsertion))
			{
				foreach (string backstory in item.backstories)
				{
					Backstory val = default(Backstory);
					if (BackstoryDatabase.TryGetWithIdentifier(backstory, ref val, true))
					{
						val.spawnCategories.AddRange(item.spawnCategories);
					}
				}
			}
		}

		public RaceSettings()
			: this()
		{
		}
	}
}
