namespace AlienRace
{
	public class AlienTraitEntry
	{
		public string defName;

		public int degree;

		public float chance = 100f;

		public float commonalityMale = -1f;

		public float commonalityFemale = -1f;
	}
}
