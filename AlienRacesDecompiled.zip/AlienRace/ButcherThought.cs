using System.Collections.Generic;

namespace AlienRace
{
	public class ButcherThought
	{
		public List<string> raceList;

		public string thought = "ButcheredHumanlikeCorpse";

		public string knowThought = "KnowButcheredHumanlikeCorpse";
	}
}
