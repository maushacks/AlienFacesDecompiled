using System.Collections.Generic;

namespace AlienRace
{
	public class GeneralSettings
	{
		public float maleGenderProbability = 0.5f;

		public bool immuneToAge;

		public bool canLayDown = true;

		public List<string> validBeds;

		public List<ChemicalSettings> chemicalSettings;

		public List<AlienTraitEntry> forcedRaceTraitEntries;

		public List<string> disallowedTraits;

		public AlienPartGenerator alienPartGenerator = new AlienPartGenerator();

		public bool useOnlyPawnkindBackstories;

		public List<FactionRelationSettings> factionRelations;

		public int maxDamageForSocialfight = int.MaxValue;

		public bool allowHumanBios;

		public bool immuneToXenophobia;

		public List<string> notXenophobistTowards = new List<string>();

		public bool humanRecipeImport;
	}
}
