using JetBrains.Annotations;
using RimWorld;
using UnityEngine;
using Verse;

namespace AlienRace
{
	[UsedImplicitly]
	public class ColorGenerator_SkinColorMelanin : ColorGenerator
	{
		public float minMelanin;

		public float maxMelanin = 1f;

		public override Color NewRandomizedColor()
		{
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			return PawnSkinColors.GetSkinColor(Rand.Range(minMelanin, maxMelanin));
		}

		public ColorGenerator_SkinColorMelanin()
			: this()
		{
		}
	}
}
