using RimWorld;
using Verse;

namespace AlienRace
{
	[DefOf]
	public static class AlienDefOf
	{
		public static TraitDef Xenophobia;

		public static ThoughtDef XenophobiaVsAlien;

		public static ThingCategoryDef alienCorpseCategory;
	}
}
