using RimWorld;
using System.Collections.Generic;

namespace AlienRace
{
	public class AteThought
	{
		public List<string> raceList;

		public string thought = "AteHumanlikeMeatDirect";

		public string thoughtCannibal = "AteHumanlikeMeatDirectCannibal";

		public string ingredientThought = "AteHumanlikeMeatAsIngredient";

		public string ingredientThoughtCannibal = "AteHumanlikeMeatAsIngredientCannibal";

		public ThoughtDef GetThought(bool cannibal, bool ingredient)
		{
			return ThoughtDef.Named((!cannibal) ? (ingredient ? ingredientThought : thought) : (ingredient ? ingredientThoughtCannibal : thoughtCannibal));
		}
	}
}
