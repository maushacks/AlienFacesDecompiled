using RimWorld;
using System.Collections.Generic;
using System.Linq;

namespace AlienRace
{
	internal static class GraphicPathsExtension
	{
		public static GraphicPaths GetCurrentGraphicPath(this List<GraphicPaths> list, LifeStageDef lifeStageDef)
		{
			return list.FirstOrDefault((GraphicPaths gp) => gp.lifeStageDefs?.Contains(lifeStageDef) ?? false) ?? list.First();
		}
	}
}
