using Verse;

namespace AlienRace
{
	public class LifeStageAgeAlien : LifeStageAge
	{
		public BodyDef body;

		public LifeStageAgeAlien()
			: this()
		{
		}
	}
}
