using Verse;

namespace AlienRace
{
	public class Info : DefModExtension
	{
		public bool useOnlyPawnkindBackstories;

		public bool allowHumanBios = true;

		public float maleGenderProbability = 0.5f;

		public Info()
			: this()
		{
		}
	}
}
