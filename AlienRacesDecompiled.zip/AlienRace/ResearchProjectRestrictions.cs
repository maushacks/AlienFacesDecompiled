using System.Collections.Generic;

namespace AlienRace
{
	public class ResearchProjectRestrictions
	{
		public List<string> projects;

		public List<string> apparelList;
	}
}
