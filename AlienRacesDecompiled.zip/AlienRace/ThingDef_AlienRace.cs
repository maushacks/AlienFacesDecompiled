using System.Collections.Generic;
using UnityEngine;
using Verse;

namespace AlienRace
{
	public class ThingDef_AlienRace : ThingDef
	{
		public class AlienSettings
		{
			public GeneralSettings generalSettings = new GeneralSettings();

			public List<GraphicPaths> graphicPaths = new List<GraphicPaths>();

			public HairSettings hairSettings = new HairSettings();

			public ThoughtSettings thoughtSettings = new ThoughtSettings();

			public RelationSettings relationSettings = new RelationSettings();

			public RaceRestrictionSettings raceRestriction = new RaceRestrictionSettings();
		}

		public AlienSettings alienRace;

		public override void ResolveReferences()
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
			base.comps.Add((CompProperties)(object)new CompProperties(typeof(AlienPartGenerator.AlienComp)));
			((ThingDef)this).ResolveReferences();
			if (GenList.NullOrEmpty<GraphicPaths>((IList<GraphicPaths>)alienRace.graphicPaths))
			{
				alienRace.graphicPaths.Add(new GraphicPaths());
			}
			if (alienRace.generalSettings.alienPartGenerator.customHeadDrawSize == Vector2.get_zero())
			{
				alienRace.generalSettings.alienPartGenerator.customHeadDrawSize = alienRace.generalSettings.alienPartGenerator.customDrawSize;
			}
			if (alienRace.generalSettings.alienPartGenerator.customPortraitHeadDrawSize == Vector2.get_zero())
			{
				alienRace.generalSettings.alienPartGenerator.customPortraitHeadDrawSize = alienRace.generalSettings.alienPartGenerator.customPortraitDrawSize;
			}
			alienRace.graphicPaths.ForEach(delegate(GraphicPaths gp)
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				//IL_0006: Unknown result type (might be due to invalid IL or missing references)
				//IL_0023: Unknown result type (might be due to invalid IL or missing references)
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_002e: Unknown result type (might be due to invalid IL or missing references)
				//IL_0033: Unknown result type (might be due to invalid IL or missing references)
				//IL_0050: Unknown result type (might be due to invalid IL or missing references)
				//IL_0055: Unknown result type (might be due to invalid IL or missing references)
				//IL_005b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0060: Unknown result type (might be due to invalid IL or missing references)
				//IL_007d: Unknown result type (might be due to invalid IL or missing references)
				//IL_0082: Unknown result type (might be due to invalid IL or missing references)
				//IL_0088: Unknown result type (might be due to invalid IL or missing references)
				//IL_008d: Unknown result type (might be due to invalid IL or missing references)
				//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
				//IL_00af: Unknown result type (might be due to invalid IL or missing references)
				//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
				//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
				//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
				//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
				if (gp.customDrawSize == Vector2.get_one())
				{
					gp.customDrawSize = alienRace.generalSettings.alienPartGenerator.customDrawSize;
				}
				if (gp.customPortraitDrawSize == Vector2.get_one())
				{
					gp.customPortraitDrawSize = alienRace.generalSettings.alienPartGenerator.customPortraitDrawSize;
				}
				if (gp.customHeadDrawSize == Vector2.get_zero())
				{
					gp.customHeadDrawSize = alienRace.generalSettings.alienPartGenerator.customHeadDrawSize;
				}
				if (gp.customPortraitHeadDrawSize == Vector2.get_zero())
				{
					gp.customPortraitHeadDrawSize = alienRace.generalSettings.alienPartGenerator.customPortraitHeadDrawSize;
				}
				if (gp.headOffset == Vector2.get_zero())
				{
					gp.headOffset = alienRace.generalSettings.alienPartGenerator.headOffset;
				}
			});
			alienRace.generalSettings.alienPartGenerator.alienProps = this;
			foreach (AlienPartGenerator.BodyAddon bodyAddon in alienRace.generalSettings.alienPartGenerator.bodyAddons)
			{
				if (bodyAddon.offsets.west == null)
				{
					bodyAddon.offsets.west = bodyAddon.offsets.east;
				}
			}
		}

		public ThingDef_AlienRace()
			: this()
		{
		}
	}
}
