using System.Collections.Generic;

namespace AlienRace
{
	public class FactionPawnKindEntry
	{
		public List<PawnKindEntry> pawnKindEntries = new List<PawnKindEntry>();

		public List<string> factionDefs = new List<string>();
	}
}
