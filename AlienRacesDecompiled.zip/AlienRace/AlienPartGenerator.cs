using Harmony;
using JetBrains.Annotations;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using UnityEngine;
using Verse;

namespace AlienRace
{
	public class AlienPartGenerator
	{
		public class BodyAddon
		{
			public string path;

			public string bodyPart;

			[Obsolete("Replaced by color channels")]
			public bool useSkinColor = true;

			public BodyAddonOffsets offsets;

			public bool linkVariantIndexWithPrevious;

			public float angle;

			public bool inFrontOfBody;

			public float layerOffset;

			public bool layerInvert = true;

			public bool drawnOnGround = true;

			public bool drawnInBed = true;

			public bool drawForMale = true;

			public bool drawForFemale = true;

			public Vector2 drawSize = Vector2.get_one();

			private string colorChannel;

			public int variantCount;

			public bool debug = true;

			public List<BodyAddonHediffGraphic> hediffGraphics;

			public List<BodyAddonBackstoryGraphic> backstoryGraphics;

			public List<BodyPartGroupDef> hiddenUnderApparelFor = new List<BodyPartGroupDef>();

			public List<string> hiddenUnderApparelTag = new List<string>();

			public string backstoryRequirement;

			private ShaderTypeDef shaderType;

			private List<BodyAddonPrioritization> prioritization;

			public string ColorChannel
			{
				get
				{
					string obj = colorChannel ?? (useSkinColor ? "skin" : "hair");
					string result = obj;
					colorChannel = obj;
					return result;
				}
			}

			public ShaderTypeDef ShaderType
			{
				get
				{
					ShaderTypeDef obj = shaderType ?? ShaderTypeDefOf.Cutout;
					ShaderTypeDef result = obj;
					shaderType = obj;
					return result;
				}
			}

			public List<BodyAddonPrioritization> Prioritization
			{
				get
				{
					List<BodyAddonPrioritization> list = prioritization;
					if (list == null)
					{
						List<BodyAddonPrioritization> obj = new List<BodyAddonPrioritization>
						{
							BodyAddonPrioritization.Hediff,
							BodyAddonPrioritization.Backstory
						};
						List<BodyAddonPrioritization> list2 = obj;
						prioritization = obj;
						list = list2;
					}
					return list;
				}
			}

			public virtual bool CanDrawAddon(Pawn pawn)
			{
				//IL_0058: Unknown result type (might be due to invalid IL or missing references)
				//IL_0126: Unknown result type (might be due to invalid IL or missing references)
				//IL_012c: Invalid comparison between Unknown and I4
				if ((GenList.NullOrEmpty<ApparelGraphicRecord>((IList<ApparelGraphicRecord>)pawn.get_Drawer().renderer.graphics.apparelGraphics) || (GenList.NullOrEmpty<string>((IList<string>)hiddenUnderApparelTag) && GenList.NullOrEmpty<BodyPartGroupDef>((IList<BodyPartGroupDef>)hiddenUnderApparelFor)) || !GenCollection.Any<Apparel>(pawn.apparel.get_WornApparel(), (Predicate<Apparel>)((Apparel ap) => GenCollection.Any<BodyPartGroupDef>(((Thing)ap).def.apparel.bodyPartGroups, (Predicate<BodyPartGroupDef>)((BodyPartGroupDef bpgd) => hiddenUnderApparelFor.Contains(bpgd))) || GenCollection.Any<string>(((Thing)ap).def.apparel.tags, (Predicate<string>)((string s) => hiddenUnderApparelTag.Contains(s)))))) && ((int)PawnUtility.GetPosture(pawn) == 0 || drawnOnGround) && ((((Thing)(RestUtility.CurrentBed(pawn)?)).def.building.bed_showSleeperBody ?? true) || drawnInBed) && (GenText.NullOrEmpty(backstoryRequirement) || pawn.story.get_AllBackstories().Any((Backstory b) => b.identifier == backstoryRequirement)))
				{
					if (!GenText.NullOrEmpty(bodyPart) && !pawn.health.hediffSet.GetNotMissingParts((BodyPartHeight)0, (BodyPartDepth)0, (BodyPartTagDef)null, (BodyPartRecord)null).Any((BodyPartRecord bpr) => bpr.untranslatedCustomLabel == bodyPart || ((Def)bpr.def).defName == bodyPart))
					{
						List<BodyAddonHediffGraphic> list = hediffGraphics;
						if (list == null || !GenCollection.Any<BodyAddonHediffGraphic>(list, (Predicate<BodyAddonHediffGraphic>)((BodyAddonHediffGraphic bahg) => bahg.hediff == ((Def)HediffDefOf.MissingBodyPart).defName)))
						{
							goto IL_013c;
						}
					}
					if ((int)pawn.gender != 2)
					{
						return drawForMale;
					}
					return drawForFemale;
				}
				goto IL_013c;
				IL_013c:
				return false;
			}

			public virtual Graphic GetPath(Pawn pawn, ref int sharedIndex, int? savedIndex = null)
			{
				//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
				//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
				//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
				//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
				string text = path;
				int num = variantCount;
				using (List<BodyAddonPrioritization>.Enumerator enumerator = Prioritization.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						switch (enumerator.Current)
						{
						case BodyAddonPrioritization.Backstory:
						{
							BodyAddonBackstoryGraphic bodyAddonBackstoryGraphic = backstoryGraphics?.FirstOrDefault((BodyAddonBackstoryGraphic babgs) => pawn.story.get_AllBackstories().Any((Backstory bs) => bs.identifier == babgs.backstory));
							if (bodyAddonBackstoryGraphic != null)
							{
								text = bodyAddonBackstoryGraphic.path;
								num = bodyAddonBackstoryGraphic.variantCount;
							}
							break;
						}
						case BodyAddonPrioritization.Hediff:
						{
							BodyAddonHediffGraphic bodyAddonHediffGraphic = hediffGraphics?.FirstOrDefault((BodyAddonHediffGraphic bahgs) => GenCollection.Any<Hediff>(pawn.health.hediffSet.hediffs, (Predicate<Hediff>)((Hediff h) => ((Def)h.def).defName == bahgs.hediff && (h.get_Part() == null || GenText.NullOrEmpty(bodyPart) || h.get_Part().untranslatedCustomLabel == bodyPart || ((Def)h.get_Part().def).defName == bodyPart))));
							if (bodyAddonHediffGraphic != null)
							{
								text = bodyAddonHediffGraphic.path;
								num = bodyAddonHediffGraphic.variantCount;
							}
							break;
						}
						default:
							throw new ArgumentOutOfRangeException();
						}
						if (!GenText.NullOrEmpty(text))
						{
							break;
						}
					}
				}
				ExposableValueTuple<Color, Color> channel = ((ThingWithComps)pawn).GetComp<AlienComp>().GetChannel(ColorChannel);
				if (GenText.NullOrEmpty(text))
				{
					return null;
				}
				int num2;
				return GraphicDatabase.Get<Graphic_Multi>(text += (((num2 = (savedIndex.HasValue ? (sharedIndex = savedIndex.Value) : (linkVariantIndexWithPrevious ? (sharedIndex % num) : (sharedIndex = Rand.Range(0, num))))) == 0) ? "" : num2.ToString()), ((Object)(object)ContentFinder<Texture2D>.Get(text + "_northm", false) == (Object)null) ? ShaderType.get_Shader() : ShaderDatabase.CutoutComplex, drawSize * 1.5f, channel.first, channel.second);
			}
		}

		public class BodyAddonHediffGraphic
		{
			public string hediff;

			public string path;

			public int variantCount;

			[UsedImplicitly]
			public void LoadDataFromXmlCustom(XmlNode xmlRoot)
			{
				hediff = xmlRoot.Name;
				path = xmlRoot.FirstChild.Value;
			}
		}

		public class BodyAddonBackstoryGraphic
		{
			public string backstory;

			public string path;

			public int variantCount;

			[UsedImplicitly]
			public void LoadDataFromXmlCustom(XmlNode xmlRoot)
			{
				backstory = xmlRoot.Name;
				path = xmlRoot.FirstChild.Value;
			}
		}

		public class BodyAddonOffsets
		{
			public RotationOffset south;

			public RotationOffset north;

			public RotationOffset east;

			public RotationOffset west;
		}

		public class RotationOffset
		{
			public List<BodyTypeOffset> portraitBodyTypes;

			public List<BodyTypeOffset> bodyTypes;

			public List<CrownTypeOffset> portraitCrownTypes;

			public List<CrownTypeOffset> crownTypes;
		}

		public class BodyTypeOffset
		{
			public BodyTypeDef bodyType;

			public Vector2 offset = Vector2.get_zero();

			[UsedImplicitly]
			public void LoadDataFromXmlCustom(XmlNode xmlRoot)
			{
				//IL_002c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0031: Unknown result type (might be due to invalid IL or missing references)
				DirectXmlCrossRefLoader.RegisterObjectWantsCrossRef((object)this, "bodyType", xmlRoot.Name);
				offset = (Vector2)ParseHelper.FromString(xmlRoot.FirstChild.Value, typeof(Vector2));
			}
		}

		public class CrownTypeOffset
		{
			public string crownType;

			public Vector2 offset = Vector2.get_zero();

			[UsedImplicitly]
			public void LoadDataFromXmlCustom(XmlNode xmlRoot)
			{
				//IL_0027: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Unknown result type (might be due to invalid IL or missing references)
				crownType = xmlRoot.Name;
				offset = (Vector2)ParseHelper.FromString(xmlRoot.FirstChild.Value, typeof(Vector2));
			}
		}

		public enum BodyAddonPrioritization : byte
		{
			Backstory,
			Hediff
		}

		public class ColorChannelGenerator
		{
			public string name = "";

			public ColorGenerator first;

			public ColorGenerator second;
		}

		public class AlienComp : ThingComp
		{
			public bool fixGenderPostSpawn;

			public Color skinColor;

			public Color skinColorSecond;

			public Color hairColorSecond;

			public string crownType;

			public Vector2 customDrawSize = Vector2.get_one();

			public Vector2 customPortraitDrawSize = Vector2.get_one();

			public AlienGraphicMeshSet alienGraphics;

			public AlienGraphicMeshSet alienPortraitGraphics;

			public List<Graphic> addonGraphics;

			public List<int> addonVariants;

			private Dictionary<string, ExposableValueTuple<Color, Color>> colorChannels;

			public Dictionary<string, ExposableValueTuple<Color, Color>> ColorChannels
			{
				get
				{
					//IL_001c: Unknown result type (might be due to invalid IL or missing references)
					//IL_0022: Expected O, but got Unknown
					//IL_004c: Unknown result type (might be due to invalid IL or missing references)
					//IL_0051: Unknown result type (might be due to invalid IL or missing references)
					//IL_006c: Unknown result type (might be due to invalid IL or missing references)
					//IL_0072: Unknown result type (might be due to invalid IL or missing references)
					//IL_0092: Unknown result type (might be due to invalid IL or missing references)
					//IL_0098: Unknown result type (might be due to invalid IL or missing references)
					//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
					//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
					if (colorChannels == null)
					{
						colorChannels = new Dictionary<string, ExposableValueTuple<Color, Color>>();
						Pawn val = (Pawn)(object)(Pawn)base.parent;
						AlienPartGenerator alienPartGenerator = ((ThingDef_AlienRace)(object)((Thing)base.parent).def).alienRace.generalSettings.alienPartGenerator;
						colorChannels.Add("base", new ExposableValueTuple<Color, Color>(Color.get_white(), Color.get_white()));
						colorChannels.Add("skin", new ExposableValueTuple<Color, Color>(skinColor, skinColorSecond));
						colorChannels.Add("hair", new ExposableValueTuple<Color, Color>(val.story.hairColor, hairColorSecond));
						foreach (ColorChannelGenerator colorChannel in alienPartGenerator.colorChannels)
						{
							colorChannels.Add(colorChannel.name, new ExposableValueTuple<Color, Color>(colorChannel.first.NewRandomizedColor(), colorChannel.second.NewRandomizedColor()));
						}
					}
					return colorChannels;
				}
			}

			public override void PostSpawnSetup(bool respawningAfterLoad)
			{
				//IL_0029: Unknown result type (might be due to invalid IL or missing references)
				//IL_002e: Unknown result type (might be due to invalid IL or missing references)
				//IL_0035: Unknown result type (might be due to invalid IL or missing references)
				//IL_003a: Unknown result type (might be due to invalid IL or missing references)
				((ThingComp)this).PostSpawnSetup(respawningAfterLoad);
				AlienPartGenerator alienPartGenerator = ((ThingDef_AlienRace)(object)((Thing)base.parent).def).alienRace.generalSettings.alienPartGenerator;
				customDrawSize = alienPartGenerator.customDrawSize;
				customPortraitDrawSize = alienPartGenerator.customPortraitDrawSize;
			}

			public override void PostExposeData()
			{
				//IL_0025: Unknown result type (might be due to invalid IL or missing references)
				//IL_002b: Unknown result type (might be due to invalid IL or missing references)
				//IL_003f: Unknown result type (might be due to invalid IL or missing references)
				//IL_0045: Unknown result type (might be due to invalid IL or missing references)
				//IL_0059: Unknown result type (might be due to invalid IL or missing references)
				//IL_005f: Unknown result type (might be due to invalid IL or missing references)
				((ThingComp)this).PostExposeData();
				Scribe_Values.Look<bool>(ref fixGenderPostSpawn, "fixAlienGenderPostSpawn", false, false);
				Scribe_Values.Look<Color>(ref skinColor, "skinColorAlien", default(Color), false);
				Scribe_Values.Look<Color>(ref skinColorSecond, "skinColorSecondAlien", default(Color), false);
				Scribe_Values.Look<Color>(ref hairColorSecond, "hairColorSecondAlien", default(Color), false);
				Scribe_Values.Look<string>(ref crownType, "crownType", (string)null, false);
				Scribe_Collections.Look<int>(ref addonVariants, "addonVariants", (LookMode)0, new object[0]);
				Scribe_Collections.Look<string, ExposableValueTuple<Color, Color>>(ref colorChannels, "colorChannels", (LookMode)0, (LookMode)0);
			}

			public ExposableValueTuple<Color, Color> GetChannel(string channel)
			{
				return ColorChannels[channel];
			}

			internal void AssignProperMeshs()
			{
				//IL_0007: Unknown result type (might be due to invalid IL or missing references)
				//IL_001d: Unknown result type (might be due to invalid IL or missing references)
				alienGraphics = meshPools[customDrawSize];
				alienPortraitGraphics = meshPools[customPortraitDrawSize];
			}

			public AlienComp()
				: this()
			{
			}//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)

		}

		public class ExposableValueTuple<K, V> : IExposable
		{
			public K first;

			public V second;

			public ExposableValueTuple()
			{
			}

			public ExposableValueTuple(K first, V second)
			{
				this.first = first;
				this.second = second;
			}

			public void ExposeData()
			{
				Scribe_Values.Look<K>(ref first, "first", default(K), false);
				Scribe_Values.Look<V>(ref second, "second", default(V), false);
			}
		}

		public class AlienGraphicMeshSet
		{
			public GraphicMeshSet bodySet;

			public GraphicMeshSet headSet;

			public GraphicMeshSet hairSetAverage;
		}

		public List<string> aliencrowntypes = new List<string>
		{
			"Average_Normal"
		};

		public List<BodyTypeDef> alienbodytypes = new List<BodyTypeDef>();

		public bool useGenderedHeads = true;

		public bool useGenderedBodies;

		public ColorGenerator alienskincolorgen;

		public ColorGenerator alienskinsecondcolorgen;

		public ColorGenerator alienhaircolorgen;

		public ColorGenerator alienhairsecondcolorgen;

		public bool useSkincolorForHair;

		public List<ColorChannelGenerator> colorChannels = new List<ColorChannelGenerator>();

		public Vector2 headOffset = Vector2.get_zero();

		public Vector2 customDrawSize = Vector2.get_one();

		public Vector2 customPortraitDrawSize = Vector2.get_one();

		public Vector2 customHeadDrawSize = Vector2.get_zero();

		public Vector2 customPortraitHeadDrawSize = Vector2.get_zero();

		public BodyPartDef headBodyPartDef;

		private static readonly Dictionary<Vector2, AlienGraphicMeshSet> meshPools = new Dictionary<Vector2, AlienGraphicMeshSet>();

		public List<BodyAddon> bodyAddons = new List<BodyAddon>();

		public ThingDef_AlienRace alienProps;

		public string RandomAlienHead(string userpath, Pawn pawn)
		{
			return GetAlienHead(userpath, useGenderedHeads ? ((object)(Gender)(ref pawn.gender)).ToString() : "", ((ThingWithComps)pawn).GetComp<AlienComp>().crownType = aliencrowntypes[Rand.Range(0, aliencrowntypes.Count)]);
		}

		public static string GetAlienHead(string userpath, string gender, string crowntype)
		{
			if (!GenText.NullOrEmpty(userpath))
			{
				return userpath + ((userpath == "Things/Pawn/Humanlike/Heads/") ? (gender + "/") : "") + ((!GenText.NullOrEmpty(gender)) ? (gender + "_") : "") + crowntype;
			}
			return "";
		}

		public Graphic GetNakedGraphic(BodyTypeDef bodyType, Shader shader, Color skinColor, Color skinColorSecond, string userpath, string gender)
		{
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			return GraphicDatabase.Get<Graphic_Multi>(GetNakedPath(bodyType, userpath, useGenderedBodies ? gender : ""), shader, Vector2.get_one(), skinColor, skinColorSecond);
		}

		public static string GetNakedPath(BodyTypeDef bodyType, string userpath, string gender)
		{
			return userpath + ((!GenText.NullOrEmpty(gender)) ? (gender + "_") : "") + "Naked_" + ((object)bodyType)?.ToString();
		}

		public Color SkinColor(Pawn alien, bool first = true)
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			AlienComp alienComp = ThingCompUtility.TryGetComp<AlienComp>((Thing)(object)alien);
			if (alienComp.skinColor != Color.get_clear())
			{
				if (!first)
				{
					return alienComp.skinColorSecond;
				}
				return alienComp.skinColor;
			}
			ColorGenerator obj = alienskincolorgen;
			alienComp.skinColor = ((obj != null) ? obj.NewRandomizedColor() : PawnSkinColors.GetSkinColor(alien.story.melanin));
			ColorGenerator obj2 = alienskinsecondcolorgen;
			alienComp.skinColorSecond = ((obj2 != null) ? obj2.NewRandomizedColor() : alienComp.skinColor);
			if (!first)
			{
				return alienComp.skinColorSecond;
			}
			return alienComp.skinColor;
		}

		public void GenerateMeshsAndMeshPools()
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			//IL_006d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			foreach (GraphicPaths item in GenCollection.Concat<GraphicPaths>((IEnumerable<GraphicPaths>)alienProps.alienRace.graphicPaths, new GraphicPaths
			{
				customDrawSize = customDrawSize,
				customHeadDrawSize = customHeadDrawSize,
				customPortraitDrawSize = customPortraitDrawSize,
				customPortraitHeadDrawSize = customPortraitHeadDrawSize
			}))
			{
				AddMeshSet(item.customDrawSize, item.customHeadDrawSize);
				AddMeshSet(item.customPortraitDrawSize, item.customPortraitHeadDrawSize);
			}
			StringBuilder logBuilder = new StringBuilder();
			bodyAddons.Do(delegate(BodyAddon ba)
			{
				if (ba.variantCount == 0)
				{
					AddToStringBuilder("loading variants for " + ba.path);
					while ((Object)(object)ContentFinder<Texture2D>.Get(ba.path + ((ba.variantCount == 0) ? "" : ba.variantCount.ToString()) + "_north", false) != (Object)null)
					{
						ba.variantCount++;
					}
					AddToStringBuilder($"Variants found for {ba.path}: {ba.variantCount}");
					if (ba.hediffGraphics != null)
					{
						foreach (BodyAddonHediffGraphic item2 in ba.hediffGraphics.Where((BodyAddonHediffGraphic bahg) => bahg.variantCount == 0))
						{
							while ((Object)(object)ContentFinder<Texture2D>.Get(item2.path + ((item2.variantCount == 0) ? "" : item2.variantCount.ToString()) + "_north", false) != (Object)null)
							{
								item2.variantCount++;
							}
							AddToStringBuilder($"Variants found for {item2.path}: {item2.variantCount}");
							if (item2.variantCount == 0)
							{
								Log.Warning("no hediff graphics found for hediff " + ba.path + ":" + item2.hediff + " in " + ((Def)alienProps).defName, false);
							}
						}
					}
					if (ba.backstoryGraphics != null)
					{
						foreach (BodyAddonBackstoryGraphic item3 in ba.backstoryGraphics.Where((BodyAddonBackstoryGraphic babg) => babg.variantCount == 0))
						{
							while ((Object)(object)ContentFinder<Texture2D>.Get(item3.path + ((item3.variantCount == 0) ? "" : item3.variantCount.ToString()) + "_north", false) != (Object)null)
							{
								item3.variantCount++;
							}
							AddToStringBuilder($"Variants found for {item3.path}: {item3.variantCount}");
							if (item3.variantCount == 0)
							{
								Log.Warning("no backstory graphics found for backstory " + ba.path + ": " + item3.backstory + " in " + ((Def)alienProps).defName, false);
							}
						}
					}
				}
				void AddToStringBuilder(string s)
				{
					if (ba.debug)
					{
						logBuilder.AppendLine(s);
					}
				}
			});
			if (logBuilder.Length > 0)
			{
				Log.Message($"loaded body addon variants for {((Def)alienProps).defName}\n{logBuilder}", false);
			}
			void AddMeshSet(Vector2 drawSize, Vector2 headDrawSize)
			{
				if (!meshPools.Keys.Any((Vector2 v) => ((object)(Vector2)(ref v)).Equals((object)drawSize)))
				{
					meshPools.Add(drawSize, new AlienGraphicMeshSet
					{
						bodySet = (GraphicMeshSet)(object)new GraphicMeshSet(1.5f * drawSize.x, 1.5f * drawSize.y),
						headSet = (GraphicMeshSet)(object)new GraphicMeshSet(1.5f * headDrawSize.x, 1.5f * headDrawSize.y),
						hairSetAverage = (GraphicMeshSet)(object)new GraphicMeshSet(1.5f * headDrawSize.x, 1.5f * headDrawSize.y)
					});
				}
			}
		}
	}
}
