namespace AlienRace
{
	public class RelationRenamer
	{
		public string relation;

		public string label;

		public string femaleLabel;
	}
}
