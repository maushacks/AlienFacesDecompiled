using JetBrains.Annotations;
using RimWorld;
using Verse;

namespace AlienRace
{
	[UsedImplicitly]
	public class ThoughtWorker_AlienVsXenophobia : ThoughtWorker
	{
		protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn otherPawn)
		{
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
			if (((Thing)p).def != ((Thing)otherPawn).def && p.get_RaceProps().get_Humanlike() && otherPawn.get_RaceProps().get_Humanlike() && RelationsUtility.PawnsKnowEachOther(p, otherPawn))
			{
				ThingDef_AlienRace thingDef_AlienRace = ((Thing)otherPawn).def as ThingDef_AlienRace;
				if (thingDef_AlienRace == null || !thingDef_AlienRace.alienRace.generalSettings.notXenophobistTowards.Contains(((Def)((Thing)p).def).defName))
				{
					ThingDef_AlienRace thingDef_AlienRace2 = ((Thing)p).def as ThingDef_AlienRace;
					if (thingDef_AlienRace2 == null || !thingDef_AlienRace2.alienRace.generalSettings.immuneToXenophobia)
					{
						if (!otherPawn.story.traits.HasTrait(AlienDefOf.Xenophobia))
						{
							return ThoughtState.op_Implicit(false);
						}
						if (otherPawn.story.traits.DegreeOfTrait(AlienDefOf.Xenophobia) != -1)
						{
							return ThoughtState.ActiveAtStage(1);
						}
						return ThoughtState.ActiveAtStage(0);
					}
				}
			}
			return ThoughtState.op_Implicit(false);
		}

		public ThoughtWorker_AlienVsXenophobia()
			: this()
		{
		}
	}
}
