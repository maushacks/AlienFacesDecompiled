using RimWorld;
using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace AlienRace
{
	[StaticConstructorOnStartup]
	public class ScenPart_StartingHumanlikes : ScenPart
	{
		private PawnKindDef kindDef;

		private int pawnCount;

		private string buffer;

		public PawnKindDef KindDef
		{
			get
			{
				PawnKindDef obj = kindDef ?? PawnKindDefOf.Villager;
				PawnKindDef result = obj;
				kindDef = obj;
				return result;
			}
			set
			{
				kindDef = value;
			}
		}

		unsafe static ScenPart_StartingHumanlikes()
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Expected O, but got Unknown
			ScenPartDef val = new ScenPartDef();
			((Def)(long)(IntPtr)(void*)val).defName = "StartingHumanlikes";
			((Def)(long)(IntPtr)(void*)val).label = "Start with humanlikes";
			((ScenPartDef)(long)(IntPtr)(void*)val).scenPartClass = typeof(ScenPart_StartingHumanlikes);
			((ScenPartDef)(long)(IntPtr)(void*)val).category = (ScenPartCategory)2;
			((ScenPartDef)(long)(IntPtr)(void*)val).selectionWeight = 1f;
			((ScenPartDef)(long)(IntPtr)(void*)val).summaryPriority = 10f;
			((Editable)val).ResolveReferences();
			((Editable)val).PostLoad();
			DefDatabase<ScenPartDef>.Add((ScenPartDef)(object)val);
		}

		public override void DoEditInterface(Listing_ScenEdit listing)
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Expected O, but got Unknown
			//IL_011b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0125: Expected O, but got Unknown
			//IL_012b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0135: Expected O, but got Unknown
			//IL_013a: Unknown result type (might be due to invalid IL or missing references)
			Rect scenPartRect = listing.GetScenPartRect((ScenPart)(object)this, ScenPart.get_RowHeight() * 3f);
			if (Widgets.ButtonText(GenUI.TopPart(scenPartRect, 0.45f), GenText.CapitalizeFirst(((Def)KindDef).label), true, false, true))
			{
				List<FloatMenuOption> list = new List<FloatMenuOption>();
				list.AddRange((from s in (from ar in DefDatabase<RaceSettings>.get_AllDefsListForReading()
						where ar.pawnKindSettings.startingColonists != null
						select ar).SelectMany((RaceSettings ar) => ar.pawnKindSettings.startingColonists.SelectMany((FactionPawnKindEntry ste) => ste.pawnKindEntries.SelectMany((PawnKindEntry pke) => pke.kindDefs)))
					where DefDatabase<PawnKindDef>.GetNamedSilentFail(s) != null
					select s).Select((Func<string, PawnKindDef>)DefDatabase<PawnKindDef>.GetNamedSilentFail).Select(delegate(PawnKindDef pkd)
				{
					//IL_003a: Unknown result type (might be due to invalid IL or missing references)
					//IL_0040: Expected O, but got Unknown
					ScenPart_StartingHumanlikes scenPart_StartingHumanlikes = this;
					return (FloatMenuOption)(object)new FloatMenuOption(GenText.CapitalizeFirst(((Def)pkd).label), (Action)delegate
					{
						scenPart_StartingHumanlikes.KindDef = pkd;
					}, (MenuOptionPriority)4, (Action)null, (Thing)null, 0f, (Func<Rect, bool>)null, (WorldObject)null);
				}));
				list.Add((FloatMenuOption)(object)new FloatMenuOption("Villager", (Action)delegate
				{
					KindDef = PawnKindDefOf.Villager;
				}, (MenuOptionPriority)4, (Action)null, (Thing)null, 0f, (Func<Rect, bool>)null, (WorldObject)null));
				list.Add((FloatMenuOption)(object)new FloatMenuOption("Slave", (Action)delegate
				{
					KindDef = PawnKindDefOf.Slave;
				}, (MenuOptionPriority)4, (Action)null, (Thing)null, 0f, (Func<Rect, bool>)null, (WorldObject)null));
				Find.get_WindowStack().Add((Window)(object)new FloatMenu(list));
			}
			Widgets.TextFieldNumeric<int>(GenUI.BottomPart(scenPartRect, 0.45f), ref pawnCount, ref buffer, 0f, 1E+09f);
		}

		public override void ExposeData()
		{
			((ScenPart)this).ExposeData();
			Scribe_Values.Look<int>(ref pawnCount, "alienRaceScenPawnCount", 0, false);
			Scribe_Defs.Look<PawnKindDef>(ref kindDef, "PawnKindDefAlienRaceScen");
		}

		public override string Summary(Scenario scen)
		{
			return ScenSummaryList.SummaryWithList(scen, "PlayerStartsWith", ScenPart_StartingThing_Defined.get_PlayerStartWithIntro());
		}

		public override IEnumerable<string> GetSummaryListEntries(string tag)
		{
			if (tag == "PlayerStartsWith")
			{
				yield return ((Def)KindDef).get_LabelCap() + " x" + pawnCount.ToString();
			}
		}

		public override bool TryMerge(ScenPart other)
		{
			ScenPart_StartingHumanlikes scenPart_StartingHumanlikes = other as ScenPart_StartingHumanlikes;
			if (scenPart_StartingHumanlikes == null || scenPart_StartingHumanlikes.KindDef != KindDef)
			{
				return false;
			}
			pawnCount += scenPart_StartingHumanlikes.pawnCount;
			return true;
		}

		public IEnumerable<Pawn> GetPawns()
		{
			for (int i = 0; i < pawnCount; i++)
			{
				Pawn val = null;
				for (int j = 0; j < 200; j++)
				{
					val = PawnGenerator.GeneratePawn(new PawnGenerationRequest(KindDef, Faction.get_OfPlayer(), (PawnGenerationContext)1, -1, true, false, false, false, true, false, 26f, true, true, true, false, false, false, false, (Predicate<Pawn>)null, (Predicate<Pawn>)null, (float?)null, (float?)null, (float?)null, (Gender?)null, (float?)null, (string)null));
					if (PawnCheck(val))
					{
						j = 200;
					}
				}
				yield return val;
			}
			bool PawnCheck(Pawn p)
			{
				if (p != null)
				{
					return (from wtd in DefDatabase<WorkTypeDef>.get_AllDefsListForReading()
						where wtd.requireCapableColonist
						select wtd).ToList().TrueForAll((WorkTypeDef w) => !p.story.WorkTypeIsDisabled(w));
				}
				return false;
			}
		}

		public ScenPart_StartingHumanlikes()
			: this()
		{
		}
	}
}
