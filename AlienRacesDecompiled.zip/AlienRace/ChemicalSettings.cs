using RimWorld;
using System.Collections.Generic;

namespace AlienRace
{
	public class ChemicalSettings
	{
		public string chemical;

		public bool ingestible = true;

		public List<IngestionOutcomeDoer> reactions;
	}
}
